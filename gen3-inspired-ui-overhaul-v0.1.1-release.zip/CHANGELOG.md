# Changelog

## 0.1.1

Stability, compatibility, readability, and PC-interface update.

- Fix duplicate native battle HUD showing beneath the custom battle UI
- Preserve native battle draw lifecycle while suppressing legacy HUD pixels
- Fix trainer-switch dialogue progression and CONT-page rendering
- Stabilize battle-dialogue font size during typewriter reveal
- Improve battle/NPC dialogue sizing, clipping, spacing, and high-resolution scaling
- Preserve native NamingScreen presentation
- Improve 1440p/4K scaling for battle/menu typography
- Tighten selected-Pokemon HP bar/value alignment
- Add dedicated Pokemon PC UI and independent PC toggle
- Theme initial PC access, storage, withdraw, deposit, release, and action flows
- Suppress native PC chrome behind the custom PC renderer
- Add Pokedex Seen and Owned counts to the PC summary
- Add total Pokemon stored across all boxes
- Add intro-only trainer party-count indicator
- Slightly enlarge and strengthen shared menu typography
- Preserve Start Menu, Bag, TM, storage, and battle logic
- Refactor large initializer into smaller module-level helpers to avoid LuaJIT upvalue limits

## 0.1

Initial public baseline.
