-- Gen 3 Inspired UI Overhaul v0.1.1
-- Presentation-only UI overhaul for Gen1Recomp.
-- Native gameplay, battle logic, menu input, storage logic, and TM flow are preserved.
-- Custom rendering is feature-gated and falls back to native behavior when disabled.

local BattleState = require("src.battle.BattleState")
local EngineFont = require("src.render.Font")
local Growth = require("src.pokemon.Growth")
local PokemonSprites = require("src.pokemon.Sprites")
local Assets = require("src.render.Assets")
local PaletteFX = require("src.render.PaletteFX")
local Menu = require("src.ui.Menu")
local StartMenu = require("src.ui.StartMenu")
local BagMenu = require("src.ui.BagMenu")
local ListMenu = require("src.ui.ListMenu")
local PartyMenu = require("src.ui.PartyMenu")
local MoveLearnMenu = require("src.ui.MoveLearnMenu")
local Strings = require("src.core.Strings")
local TextBox = require("src.render.TextBox")
local ChoiceBox = require("src.ui.ChoiceBox")
local NamingScreen = require("src.ui.NamingScreen")
local BoxMenu = require("src.ui.BoxMenu")
local Boxes = require("src.pokemon.Boxes")

local activeBattle = nil
local activeParty = nil
local activeTMParty = nil
local activeMoveLearn = nil
local activeTMPromptFlow = nil
local activeStartMenu = nil
local activeBagMenu = nil
local activeBagActionMenu = nil
local activeDialogueBox = nil
local activeChoiceBox = nil
local activePCMenu = nil
local activePCList = nil
local activePCActionMenu = nil
local activePCAccessMenu = nil


local modRef = nil

local OPTION_DEFAULTS = {
  revampedBattleUI = true,
  revampedPokemonMenu = true,
  revampedOverworldMenus = true,
  revampedPokemonPC = true,
  revampedDialogueBoxes = true,
  uiBorderColor = "gold",
  uiBorderStyle = "classic",
}

local function optionValue(key)
  if modRef and modRef.options and modRef.options.get then
    local ok, value = pcall(modRef.options.get, modRef.options, key)
    if ok and value ~= nil then return value end
  end
  return OPTION_DEFAULTS[key]
end

local function featureEnabled(key)
  return optionValue(key) ~= false
end


local function bagStateForMenu(game)
  if not (game and game.stack and game.stack.states) then return nil end
  for i=#game.stack.states,1,-1 do
    local state = game.stack.states[i]
    if state and state.__gen3uiBag then
      return state
    end
  end
  return nil
end


local function stateExistsInStack(game, target)
  if not (game and game.stack and game.stack.states and target) then return false end
  for _,state in ipairs(game.stack.states) do
    if state == target then return true end
  end
  return false
end


local function pcMenuLabel(item)
  return tostring(item and item.label or ""):upper()
end

local function pcAccessItems(items)
  if type(items)~="table" or #items<2 then return false end
  local hits=0
  for _,item in ipairs(items) do
    local label=pcMenuLabel(item)
    if label:find("PC",1,true) or label=="LOG OFF" then hits=hits+1 end
  end
  return hits>=2 and pcMenuLabel(items[#items])=="LOG OFF"
end

local function pcMainItems(items)
  if type(items)~="table" or #items<4 then return false end
  local labels={}
  for i,item in ipairs(items) do labels[i]=pcMenuLabel(item) end
  return labels[1]:find("WITHDRAW",1,true)
      and labels[2]:find("DEPOSIT",1,true)
      and labels[3]:find("RELEASE",1,true)
      and labels[4]:find("CHANGE BOX",1,true)
end

local function pcActionItems(items)
  if type(items)~="table" or #items<3 then return false end
  local a=pcMenuLabel(items[1])
  return (a=="WITHDRAW" or a=="DEPOSIT")
      and pcMenuLabel(items[2])=="STATS"
      and pcMenuLabel(items[3])=="CANCEL"
end

local function pcListTitle(title)
  local t=tostring(title or ""):upper()
  if t=="PARTY (DEPOSIT)" or t=="CHANGE BOX" then return true end
  if t:match("^BOX %d+ %(WITHDRAW%)$") then return true end
  if t:match("^BOX %d+ %(RELEASE%)$") then return true end
  return false
end

local function isPCOwnedState(state)
  return state and (
    state.__gen3uiPCAccess
    or state.__gen3uiPCMain
    or state.__gen3uiPCList
    or state.__gen3uiPCAction
  )
end

local function pcStateInStack(game)
  if not (game and game.stack and game.stack.states) then return nil end
  for i=#game.stack.states,1,-1 do
    local state=game.stack.states[i]
    if isPCOwnedState(state) then return state end
  end
  return nil
end


local function supportedOverworldMenuState(state)
  if not state then return false end

  -- These are the menu classes for which this mod has complete replacement
  -- renderers. Everything else fails safely to the native implementation.
  if state.__gen3uiStart then return true end
  if getmetatable(state)==BagMenu then return true end
  if getmetatable(state)==PartyMenu then return true end
  if getmetatable(state)==MoveLearnMenu then return true end

  -- Bag item action menus are marked explicitly by our own hook.
  if state.__gen3uiBagAction or state.__gen3uiBag then return true end
  if isPCOwnedState(state) then return true end

  return false
end


local function canIntegrateMoveLearn(game, moveMenu)
  if not featureEnabled("revampedPokemonMenu") then return false end
  if not (activeTMParty and moveMenu and moveMenu.mon) then return false end
  if not stateExistsInStack(game, activeTMParty) then return false end

  local party = activeTMParty.party or (game.save and game.save.party) or {}
  local selected = math.max(1, math.min(activeTMParty.index or 1, #party))
  return party[selected] == moveMenu.mon
end

local function installVerifiedOptions(mod)
  modRef = mod

  -- This exact row format is consumed by ManagerState's options screen:
  -- type=toggle, key, label, default.
  mod.options:define({
    {
      key = "revampedBattleUI",
      type = "toggle",
      label = "BATTLE UI",
      default = true,
    },
    {
      key = "revampedPokemonMenu",
      type = "toggle",
      label = "POKéMON MENU",
      default = true,
    },
    {
      key = "revampedOverworldMenus",
      type = "toggle",
      label = "OVERWORLD MENUS",
      default = true,
    },
    {
      key = "revampedPokemonPC",
      type = "toggle",
      label = "POKéMON PC UI",
      default = true,
    },
    {
      key = "revampedDialogueBoxes",
      type = "toggle",
      label = "DIALOGUE / TEXT BOXES",
      default = true,
    },
    {
      key = "uiBorderColor",
      type = "choice",
      label = "BORDER COLOR",
      default = "gold",
      choices = {
        {"GOLD", "gold"},
        {"RED", "red"},
        {"ORANGE", "orange"},
        {"YELLOW", "yellow"},
        {"GREEN", "green"},
        {"CYAN", "cyan"},
        {"BLUE", "blue"},
        {"PURPLE", "purple"},
        {"PINK", "pink"},
        {"BROWN", "brown"},
        {"GRAY", "gray"},
        {"WHITE", "white"},
        {"BLACK", "black"},
      },
    },
    {
      key = "uiBorderStyle",
      type = "choice",
      label = "BORDER STYLE",
      default = "classic",
      choices = {
        {"CLASSIC", "classic"},
        {"DOUBLE", "double"},
        {"BOLD", "bold"},
        {"DASHED", "dashed"},
        {"DOTTED", "dotted"},
        {"STRIPED", "striped"},
        {"CHECKER", "checker"},
        {"MINIMAL", "minimal"},
      },
    },
  })

  if mod.log then
    mod.log:info("Gen 3 Inspired UI Overhaul: verified Mod Manager options registered")
  end
end


local fonts = {}
local dramaticShapePatched = false
local vanillaTextPatched = false
local overworldUIPatched = false
local overworldFonts = {}
local partyRenderOX, partyRenderOY, partyRenderScale = 0, 0, 1

-- -------------------------------------------------------------------------
-- Helpers
-- -------------------------------------------------------------------------

local function clamp(v, lo, hi)
  if v < lo then return lo end
  if v > hi then return hi end
  return v
end

local function shownHP(b)
  if not b then return 0 end
  return math.max(0, math.floor(b.shownHP or (b.mon and b.mon.hp) or 0))
end

local function maxHP(b)
  return math.max(1, math.floor(
    (b and b.mon and b.mon.stats and b.mon.stats.hp) or 1
  ))
end

local function speciesDef(battle, battler)
  if not (battle and battle.data and battle.data.pokemon and battler
      and battler.mon and battler.mon.species) then return nil end
  return battle.data.pokemon[battler.mon.species]
end

local function expRatio(battle, battler)
  local mon = battler and battler.mon
  local def = speciesDef(battle, battler)
  if not (mon and def) then return 0 end

  local cap = (battle.data.constants and battle.data.constants.levelCap) or 100
  local level = math.max(1, math.floor(mon.level or 1))
  if level >= cap then return 1 end

  local rates = battle.data.growth_rates
  local cur = Growth.expForLevel(def.growthRate, level, rates)
  local nxt = Growth.expForLevel(def.growthRate, level + 1, rates)
  return clamp(((mon.exp or cur) - cur) / math.max(1, nxt - cur), 0, 1)
end

local function safeExpRatio(battle, battler)
  local ok, value = pcall(expRatio, battle, battler)
  if not ok or type(value) ~= "number" or value ~= value then
    return 0
  end
  return clamp(value, 0, 1)
end

local function battleInStack(game, battle)
  if not (game and game.stack and game.stack.states and battle) then return false end
  for _, state in ipairs(game.stack.states) do
    if state == battle then return true end
  end
  return false
end

local function topState(game)
  if not (game and game.stack) then return nil end
  if game.stack.top then
    local ok,state=pcall(game.stack.top,game.stack)
    if ok and state then return state end
  end
  local states=game.stack.states
  return states and states[#states] or nil
end

local function namingScreenOwnsForeground(game)
  local top=topState(game)
  if not top then return false end

  -- Current Gen1Recomp NamingScreen uses this metatable. screenId keeps this
  -- safe for registered/mod-provided naming screens following Screens' contract.
  return getmetatable(top)==NamingScreen
      or top.screenId=="NamingScreen"
      or top.screenId=="naming"
end

local function battleOwnsForeground(game, battle)
  if not (game and game.stack and battle) then return false end
  local top = game.stack.top and game.stack:top()
      or (game.stack.states and game.stack.states[#game.stack.states])
  return top == battle
end

local function shouldDrawStatusHUD(game, battle)
  -- Bag, Party, Summary, Naming, etc. are pushed above BattleState. When one
  -- owns the foreground, no battle status chrome should leak over it.
  if not battleOwnsForeground(game, battle) then return false end

  -- Move selection is a full battle-owned menu rather than a battlefield
  -- prompt. Its larger panel intentionally gets the full lower-right region.
  if battle.phase == "moveSelect" or battle.phase == "mimicSelect" then
    return false
  end

  return true
end

local function enemyVisible(battle)
  if not battle or not battle.enemy or battle.showEnemyTrainer
      or battle.enemySendingOut then return false end
  if battle.enemy.fainted or battle.introBalls then return false end
  if battle.growInScale and battle:growInScale(battle.enemy) then return false end
  return (battle.introSlide or 0) == 0
end

local function playerVisible(battle)
  if not battle or battle.safari or battle.demo or not battle.player
      or battle.showPlayerBack then return false end
  return (battle.introSlide or 0) == 0
end

local function statusText(battle, battler)
  if not battler or not battler.shownStatus then return nil end
  if battle and battle.statusLabel then
    local ok, label = pcall(battle.statusLabel, battle,
      { status = battler.shownStatus })
    if ok and label and label ~= "" then return tostring(label):upper() end
  end
  return tostring(battler.shownStatus):upper()
end

local function statusColor(label)
  label = tostring(label or ""):upper()
  if label:find("PSN", 1, true) or label:find("TOX", 1, true) then
    return 0.54, 0.18, 0.67, 1
  elseif label:find("PAR", 1, true) then
    return 0.84, 0.59, 0.04, 1
  elseif label:find("BRN", 1, true) then
    return 0.84, 0.26, 0.09, 1
  elseif label:find("FRZ", 1, true) then
    return 0.13, 0.52, 0.76, 1
  elseif label:find("SLP", 1, true) then
    return 0.34, 0.37, 0.42, 1
  end
  return 0.26, 0.26, 0.24, 1
end

local function hpColor(ratio)
  if ratio > 0.50 then return 0.24, 0.79, 0.42, 1 end
  if ratio > 0.20 then return 0.94, 0.68, 0.09, 1 end
  return 0.88, 0.17, 0.12, 1
end

-- -------------------------------------------------------------------------
-- Dramatic Shape compatibility adapter (known-good v0.2.6 approach)
-- -------------------------------------------------------------------------

local function patchDramaticShape(game, mod)
  if dramaticShapePatched then return true end

  local exports = game and game.mods and game.mods.exports
  local handle = exports and exports.DRAMATIC_SHAPE
  local lib = handle and handle.lib
  if not (lib and type(lib.require) == "function") then return false end

  local okOB, OB = pcall(lib.require, "OverworldBattle")
  local okBH, BH = pcall(lib.require, "BattleHud")
  if not (okOB and OB and okBH and BH) then return false end

  if not OB.__gen3ui_originalSnapHUDs then
    OB.__gen3ui_originalSnapHUDs = OB.snapHUDs
  end
  if not OB.__gen3ui_originalDrawHudPanels then
    OB.__gen3ui_originalDrawHudPanels = OB.drawHudPanels
  end
  if not BH.__gen3ui_originalPanel then
    BH.__gen3ui_originalPanel = BH.panel
  end

  OB.snapHUDs = function(battle, shot)
    if not (battle and shot and shot.canvas and (shot.scale or 0) > 0) then
      return false
    end
    return true
  end
  OB.drawHudPanels = function() end
  BH.panel = function() return true end

  dramaticShapePatched = true
  if mod and mod.log then
    pcall(function()
      mod.log("info", "Gen 3 Inspired UI Overhaul: Dramatic Shape adapter active")
    end)
  end
  return true
end

-- -------------------------------------------------------------------------
-- Vanilla battle text/menu visual suppression
-- -------------------------------------------------------------------------

local function runDrawInvisible(fn, self, ...)
  -- Do not skip an engine/mod draw method just because we own its pixels.
  -- Some presentation methods also advance presentation state (for example
  -- BattleState:drawTextArea decays scrollPx). Run them with an empty scissor
  -- so their lifecycle stays native while no legacy pixels reach the frame.
  local g=love.graphics
  g.push("all")
  g.setScissor(0,0,0,0)
  local ok,result=pcall(fn,self,...)
  g.pop()
  if not ok then error(result) end
  return result
end

local function patchVanillaTextDrawing()
  if vanillaTextPatched then return end
  vanillaTextPatched = true

  -- Chain whatever implementation exists when this mod loads.
  local originalTextArea = BattleState.drawTextArea
  if originalTextArea then
    BattleState.drawTextArea = function(self, ...)
      if not featureEnabled("revampedBattleUI") then
        return originalTextArea(self, ...)
      end

      if self.phase=="messages"
          or (self.phase=="menu" and not self.safari and not self.demo)
          or self.phase=="moveSelect" then
        return runDrawInvisible(originalTextArea,self,...)
      end

      return originalTextArea(self,...)
    end
  end

  local originalHUDs = BattleState.drawHUDs
  if originalHUDs then
    BattleState.drawHUDs = function(self, slide, ...)
      if not featureEnabled("revampedBattleUI") then
        return originalHUDs(self,slide,...)
      end

      -- Preserve the complete native/modded HUD draw lifecycle without letting
      -- its pixels through. Some other mods also hang behavior off drawHUDs().
      runDrawInvisible(originalHUDs,self,slide,...)
    end
  end

  -- Trainer party count belongs to the OPENING battle presentation, not the
  -- persistent battle HUD. Draw it directly after BattleState.draw() while
  -- Gen1Recomp's own introBalls flag is active. This runs on the same battle
  -- surface as the intro itself, after the suppressed native HUD has finished.
  local originalBattleDraw = BattleState.draw
  if originalBattleDraw then
    BattleState.draw = function(self, ...)
      local result=originalBattleDraw(self,...)

      if featureEnabled("revampedBattleUI")
          and self.introBalls
          and type(self.enemyParty)=="table"
          and #self.enemyParty>0 then
        local g=love.graphics
        g.push("all")

        -- Native-style logical battle coordinates. Six slots are always shown:
        -- red/white = usable Pokémon, gray = fainted, outline = empty.
        local x0,y0=64,16
        local gap=-8
        local r=3.2

        g.setColor(0.10,0.10,0.10,0.95)
        g.rectangle("fill",17,22,54,2)

        for i=1,6 do
          local mon=self.enemyParty[i]
          local cx=x0+(i-1)*gap
          if mon then
            local alive=(mon.hp or 0)>0
            g.setColor(alive and {0.92,0.18,0.14,1}
                             or {0.42,0.42,0.40,0.85})
            g.arc("fill","pie",cx,y0,r,math.pi,math.pi*2)
            g.setColor(0.96,0.96,0.92,1)
            g.arc("fill","pie",cx,y0,r,0,math.pi)
            g.setColor(0.08,0.08,0.08,1)
            g.setLineWidth(0.8)
            g.circle("line",cx,y0,r)
            g.line(cx-r,y0,cx+r,y0)
            g.setColor(0.98,0.98,0.95,1)
            g.circle("fill",cx,y0,0.9)
            g.setColor(0.08,0.08,0.08,1)
            g.circle("line",cx,y0,0.9)
          else
            g.setColor(0.32,0.32,0.30,0.55)
            g.setLineWidth(0.8)
            g.circle("line",cx,y0,r)
          end
        end

        g.pop()
      end

      return result
    end
  end
end

-- -------------------------------------------------------------------------
-- Assets and smooth screen fonts
-- -------------------------------------------------------------------------

local function font(size)
  size = math.max(4, math.floor(size + 0.5))
  if fonts[size] then return fonts[size] end

  local ok, f = pcall(love.graphics.newFont,
    EngineFont.PLAINPIXEL, size, "normal")
  if not ok or not f then
    local fallback = love.graphics.getFont()
    fonts[size] = fallback
    return fallback
  end

  if f.setFilter then pcall(f.setFilter, f, "linear", "linear") end
  fonts[size] = f
  return f
end

local function printText(text, x, y, size, color, align, width)
  local g = love.graphics
  local f = font(size)
  local old = g.getFont()
  g.setFont(f)

  text = tostring(text or "")
  color = color or {0.11,0.12,0.11,1}
  local shadow = {0.14,0.16,0.13,0.24}

  if width then
    g.setColor(shadow)
    g.printf(text, x+1, y+1, width, align or "left")
    g.setColor(color)
    g.printf(text, x, y, width, align or "left")
  else
    g.setColor(shadow)
    g.print(text, x+1, y+1)
    g.setColor(color)
    g.print(text, x, y)
  end

  if old then g.setFont(old) end
  g.setColor(1,1,1,1)
end

local function fittedTextSize(text, preferred, minimum, maxWidth)
  text=tostring(text or "")
  local size=math.max(minimum or 4,preferred or 4)
  local floorSize=math.max(4,minimum or 4)
  while size > floorSize and font(size):getWidth(text) > maxWidth do
    size=size-1
  end
  return math.max(floorSize,size)
end


local function fittedDialogueMetrics(lines, preferred, minimum, maxWidth, maxHeight)
  local size=math.max(minimum or 4,preferred or 4)
  local floorSize=math.max(4,minimum or 4)
  local visible=math.max(1,#(lines or {}))

  while size > floorSize do
    local f=font(size)
    local fitsWidth=true
    for i=1,visible do
      if f:getWidth(tostring(lines[i] or "")) > maxWidth then
        fitsWidth=false
        break
      end
    end

    -- Use the font's ACTUAL line box rather than assuming fontSize == height.
    local glyphH=f:getHeight()
    local lineH=math.ceil(glyphH*1.06)
    local blockH=glyphH + math.max(0,visible-1)*lineH

    if fitsWidth and blockH <= maxHeight then
      return size,glyphH,lineH,blockH
    end
    size=size-1
  end

  local f=font(floorSize)
  local glyphH=f:getHeight()
  local lineH=math.ceil(glyphH*1.04)
  local blockH=glyphH + math.max(0,visible-1)*lineH
  return floorSize,glyphH,lineH,blockH
end

-- BattleState.current.text is already the actual localized, human-readable
-- message string. The engine only converts it to glyph codes for the vanilla
-- typewriter. Using the source string avoids lossy reverse-charmap decoding.
local function splitBattleMessageText(text)
  text=tostring(text or "")
  local out={}
  local pos=1
  while true do
    local s,e=text:find("[\n\v]",pos)
    if not s then
      out[#out+1]=text:sub(pos)
      break
    end
    out[#out+1]=text:sub(pos,s-1)
    pos=e+1
  end
  return out
end

local function revealedGlyphText(source, count)
  source=tostring(source or "")
  count=math.max(0,tonumber(count) or 0)
  if count==0 then return "" end

  -- EngineFont.split uses the exact active Gen1Recomp charmap, so multi-byte
  -- glyphs such as é and mod-provided glyph sequences stay intact.
  local spans=EngineFont.split(source)
  if count>=#spans then return source end
  local last=spans[count]
  return last and source:sub(1,last.to) or ""
end

local function messageLines(battle)
  -- BattleState.shown is THE engine's rendered rolling two-line window.
  -- Do not reconstruct CONT/newline state ourselves. `shown` already accounts
  -- for typing progress, beginMsgLine(), CONT scrolling, and sayChoice pages.
  local shown=battle and battle.shown or nil
  local source=battle and battle.current and battle.current.text or nil

  if shown and source and #shown>0 then
    local sourceLines=splitBattleMessageText(source)
    local lineIndex=math.max(1,tonumber(battle.lineIndex) or 1)
    local firstSource=math.max(1,lineIndex-#shown+1)
    local out={}

    for visibleIndex,codes in ipairs(shown) do
      local sourceIndex=firstSource+visibleIndex-1
      local full=sourceLines[sourceIndex] or ""
      out[#out+1]=revealedGlyphText(full,#(codes or {}))
    end

    battle.__gen3VisibleMessageLines=out
    return out
  end

  -- Animations may deliberately retain the prior typed page after current is
  -- cleared; mirror BattleState.drawTextArea's msgHold behavior.
  return (battle and battle.__gen3VisibleMessageLines) or {}
end

local function messagePageFullLines(battle)
  local source=battle and battle.current and battle.current.text or nil
  local shown=battle and battle.shown or nil
  if not source or not shown or #shown==0 then
    return battle and battle.__gen3FullMessageLines or {}
  end

  local sourceLines=splitBattleMessageText(source)
  local lineIndex=math.max(1,tonumber(battle.lineIndex) or 1)
  local firstSource=math.max(1,lineIndex-#shown+1)
  local out={}
  for i=1,#shown do
    out[#out+1]=sourceLines[firstSource+i-1] or ""
  end

  battle.__gen3FullMessageLines=out
  return out
end

local function displayName(battler)
  local raw = battler and (
    battler.name
    or (battler.mon and battler.mon.nickname)
    or (battler.mon and battler.mon.name)
  )
  return tostring(raw or "POKEMON")
end

local function roundedRect(mode, x, y, w, h, r)
  love.graphics.rectangle(mode, x, y, w, h, r, r)
end

local UI_BORDER_COLORS = {
  gold   = {0.72,0.58,0.30,1},
  red    = {0.78,0.18,0.16,1},
  orange = {0.90,0.43,0.12,1},
  yellow = {0.88,0.72,0.14,1},
  green  = {0.19,0.62,0.30,1},
  cyan   = {0.14,0.65,0.70,1},
  blue   = {0.18,0.42,0.78,1},
  purple = {0.48,0.27,0.68,1},
  pink   = {0.82,0.37,0.57,1},
  brown  = {0.47,0.30,0.17,1},
  gray   = {0.46,0.47,0.45,1},
  white  = {0.91,0.91,0.87,1},
  black  = {0.08,0.08,0.07,1},
}

local function currentBorderColor()
  return UI_BORDER_COLORS[optionValue("uiBorderColor")] or UI_BORDER_COLORS.gold
end

local function setCurrentBorderColor(alpha)
  local c = currentBorderColor()
  love.graphics.setColor(c[1],c[2],c[3],alpha or 1)
end

local function currentBorderStyle()
  return optionValue("uiBorderStyle") or "classic"
end

local function borderLine(x,y,w,h,r)
  if r and r > 0 then
    roundedRect("line",x,y,w,h,r)
  else
    love.graphics.rectangle("line",x,y,w,h)
  end
end

local function drawUnifiedBorder(x,y,w,h,r)
  local g = love.graphics
  local style = currentBorderStyle()
  r = r or 0
  setCurrentBorderColor(1)
  g.setLineWidth(1)

  if style == "minimal" then
    g.line(x+3,y+h-3,x+w-3,y+h-3)

  elseif style == "double" then
    borderLine(x+2,y+2,w-4,h-4,math.max(0,r-1))
    borderLine(x+4,y+4,w-8,h-8,math.max(0,r-2))

  elseif style == "bold" then
    g.setLineWidth(3)
    borderLine(x+3,y+3,w-6,h-6,math.max(0,r-2))

  elseif style == "dashed" then
    for xx=x+3,x+w-5,6 do
      g.line(xx,y+3,math.min(xx+3,x+w-3),y+3)
      g.line(xx,y+h-3,math.min(xx+3,x+w-3),y+h-3)
    end
    for yy=y+3,y+h-5,6 do
      g.line(x+3,yy,x+3,math.min(yy+3,y+h-3))
      g.line(x+w-3,yy,x+w-3,math.min(yy+3,y+h-3))
    end

  elseif style == "dotted" then
    for xx=x+3,x+w-3,5 do
      g.points(xx,y+3)
      g.points(xx,y+h-3)
    end
    for yy=y+3,y+h-3,5 do
      g.points(x+3,yy)
      g.points(x+w-3,yy)
    end

  elseif style == "striped" then
    for xx=x+3,x+w-7,7 do
      g.polygon("fill",xx,y+2,xx+3,y+2,xx+6,y+5,xx+3,y+5)
      g.polygon("fill",xx,y+h-5,xx+3,y+h-5,xx+6,y+h-2,xx+3,y+h-2)
    end
    g.rectangle("fill",x+2,y+3,2,h-6)
    g.rectangle("fill",x+w-4,y+3,2,h-6)

  elseif style == "checker" then
    for xx=x+3,x+w-5,5 do
      if math.floor((xx-x)/5)%2 == 0 then
        g.rectangle("fill",xx,y+2,3,3)
        g.rectangle("fill",xx,y+h-5,3,3)
      end
    end
    for yy=y+3,y+h-5,5 do
      if math.floor((yy-y)/5)%2 == 1 then
        g.rectangle("fill",x+2,yy,3,3)
        g.rectangle("fill",x+w-5,yy,3,3)
      end
    end

  else -- classic
    borderLine(x+3,y+3,w-6,h-6,math.max(0,r-2))
  end

  g.setLineWidth(1)
  g.setColor(1,1,1,1)
end


-- -------------------------------------------------------------------------
-- Status HUD
-- -------------------------------------------------------------------------

local function hudScale()
  local sw,sh=love.graphics.getDimensions()
  local raw=math.min(sw/430,sh/245)

  -- Keep the established size at <=1080p, but do not leave 1440p/4K users
  -- with a HUD permanently capped at a 1080p pixel size.
  if raw <= 4.5 then
    return clamp(raw,2.85,3.85)
  end
  return clamp(3.85 + (raw-4.5)*0.72,3.85,7.0)
end

local function drawPlate(x, y, w, h, s)
  local g = love.graphics
  local radius = 7*s

  -- Deep teal cast shadow.
  g.setColor(0.11,0.22,0.21,0.78)
  roundedRect("fill", x+4*s, y+5*s, w, h, radius)

  -- Globally selected border color.
  setCurrentBorderColor(1)
  roundedRect("fill", x-1.2*s, y-1.2*s, w+2.4*s, h+2.4*s, radius+1*s)

  -- Dark green-gray frame.
  g.setColor(0.24,0.31,0.28,1)
  roundedRect("fill", x, y, w, h, radius)

  -- Cream face.
  g.setColor(0.965,0.945,0.86,1)
  roundedRect("fill", x+2.4*s, y+2.4*s, w-4.8*s, h-4.8*s, radius-1.5*s)

  -- Inner highlight.
  g.setColor(1.0,0.99,0.94,0.9)
  g.setLineWidth(math.max(1.2,0.7*s))
  roundedRect("line", x+4*s, y+4*s, w-8*s, h-8*s, radius-2*s)
  drawUnifiedBorder(x,y,w,h,radius)
end

local function drawStyledHP(x, y, w, h, battler)
  local g = love.graphics
  local hp, mx = shownHP(battler), maxHP(battler)
  local ratio = clamp(hp / mx, 0, 1)

  -- Dark HP capsule.
  local badgeW = h * 1.95
  g.setColor(0.18,0.31,0.29,1)
  roundedRect("fill", x, y, badgeW, h, h*0.38)
  printText("HP", x+badgeW*0.18, y+h*0.00, h*0.72,
            {0.96,0.72,0.18,1})

  local bx = x + badgeW - h*0.20
  local bw = w - badgeW + h*0.20

  g.setColor(0.18,0.24,0.22,1)
  roundedRect("fill", bx,y,bw,h,h*0.38)
  g.setColor(0.73,0.72,0.62,1)
  roundedRect("fill", bx+2,y+2,bw-4,h-4,math.max(2,h*0.27))

  local innerW = math.max(0,bw-4)
  local fillW = innerW * ratio
  if hp > 0 then fillW = math.max(2,fillW) end
  if fillW > 0 then
    local r,gg,b,a = hpColor(ratio)
    g.setColor(r,gg,b,a)
    roundedRect("fill", bx+2,y+2,fillW,h-4,math.max(2,h*0.25))
    g.setColor(math.min(1,r+0.18),math.min(1,gg+0.18),
               math.min(1,b+0.18),0.80)
    roundedRect("fill",bx+4,y+3,math.max(0,fillW-4),
                math.max(2,(h-4)*0.28),2)
  end
end

local function drawEXPRow(plateX, plateY, plateW, plateH, battle, battler, s)
  local g = love.graphics
  local ratio = safeExpRatio(battle, battler)

  -- Exact player-plate-relative geometry.
  local left = plateX + 7*s
  local right = plateX + plateW - 6*s
  local labelW = 22*s
  local barH = 4.6*s
  local rowY = plateY + plateH - 9*s

  -- EXP label: warm Gen III yellow.
  pcall(printText, "EXP", left, rowY - 0.9*s,
        3.9*s, {0.86,0.64,0.08,1})

  -- Rail begins after label and stretches to the right plate inset.
  local barX = left + labelW
  local barW = math.max(8*s, right - barX)

  -- Outer dark teal capsule.
  g.setColor(0.10,0.20,0.23,1)
  roundedRect("fill", barX, rowY, barW, barH, 2.0*s)

  -- Blue-tinted empty track so the EXP row is recognizable even at 0%.
  local pad = 0.9*s
  local ix = barX + pad
  local iy = rowY + pad
  local iw = math.max(1, barW - pad*2)
  local ih = math.max(1, barH - pad*2)

  g.setColor(0.18,0.31,0.43,1)
  roundedRect("fill", ix, iy, iw, ih, 1.2*s)

  -- Live blue EXP fill.
  local fw = iw * ratio
  if fw > 0 then
    g.setColor(0.03,0.39,0.96,1)
    roundedRect("fill", ix, iy, fw, ih, 1.2*s)

    -- Cyan highlight gives it the FireRed/GBA gloss.
    g.setColor(0.40,0.80,1.00,0.98)
    roundedRect("fill",
                ix + 0.4*s,
                iy + 0.25*s,
                math.max(0, fw - 0.8*s),
                math.max(1, ih*0.30),
                0.4*s)
  end

  g.setColor(1,1,1,1)
end

local function drawMiniPartyBall(cx,cy,r,state)
  local g=love.graphics
  local alive=state=="alive"
  local occupied=state~="empty"

  if not occupied then
    g.setColor(0.35,0.36,0.35,0.40)
    g.setLineWidth(math.max(1,r*0.20))
    g.circle("line",cx,cy,r)
    return
  end

  g.setColor(alive and {0.94,0.24,0.18,1} or {0.42,0.42,0.40,0.72})
  g.arc("fill","pie",cx,cy,r,math.pi,math.pi*2)
  g.setColor(0.96,0.96,0.92,1)
  g.arc("fill","pie",cx,cy,r,0,math.pi)
  g.setColor(0.10,0.10,0.09,1)
  g.setLineWidth(math.max(1,r*0.18))
  g.circle("line",cx,cy,r)
  g.line(cx-r,cy,cx+r,cy)
  g.setColor(0.97,0.97,0.93,1)
  g.circle("fill",cx,cy,r*0.28)
  g.setColor(0.10,0.10,0.09,1)
  g.circle("line",cx,cy,r*0.28)
end


local function drawEnemyHUD(battle, s)
  if not enemyVisible(battle) then return end

  local margin=7*s
  local w,h=112*s,31*s
  local x,y=margin,margin
  local b=battle.enemy

  drawPlate(x,y,w,h,s)

  local textColor={0.11,0.12,0.11,1}
  printText(displayName(b),x+7*s,y+2.0*s,6.4*s,textColor)
  printText("Lv."..tostring((b.mon and b.mon.level) or "?"),
            x+64*s,y+2.2*s,5.5*s,textColor,"right",39*s)

  drawStyledHP(x+7*s,y+14.5*s,97*s,7*s,b)

  local status=statusText(battle,b)
  if status then
    local r,g,bb,aa=statusColor(status)
    printText(status,x+8*s,y+22.0*s,3.8*s,{r,g,bb,aa})
  end
end

local function drawPlayerHUD(battle, s, commandRect)
  if not playerVisible(battle) then return end

  local sw=love.graphics.getWidth()
  local w,h=116*s,45*s
  local margin=7*s
  local x=sw-w-margin
  local y=commandRect.y-h-6*s
  local b=battle.player

  -- Core geometry first. These are intentionally not dependent on font rendering.
  drawPlate(x,y,w,h,s)
  drawStyledHP(x+8*s,y+13.8*s,101*s,7.2*s,b)

  -- EXP is a core HUD primitive now, not a decorative tail-end draw.
  -- It renders before any potentially failing status/number typography.
  drawEXPRow(x, y, w, h, battle, b, s)

  local textColor={0.11,0.12,0.11,1}

  -- Name and level are independently protected.
  pcall(function()
    printText(displayName(b),x+8*s,y+1.8*s,6.4*s,textColor)
  end)
  pcall(function()
    printText("Lv."..tostring((b.mon and b.mon.level) or "?"),
              x+65*s,y+2.1*s,5.4*s,textColor,"right",41*s)
  end)

  -- Status cannot stop HP numbers or EXP.
  pcall(function()
    local status=statusText(battle,b)
    if status then
      local r,g,bb,aa=statusColor(status)
      local lg=love.graphics
      lg.setColor(r,g,bb,0.12)
      roundedRect("fill",x+8*s,y+22.2*s,25*s,7.0*s,2.4*s)
      printText(status,x+10*s,y+22.0*s,3.8*s,{r,g,bb,aa})
      lg.setColor(1,1,1,1)
    end
  end)

  -- Numeric HP is also isolated.
  pcall(function()
    local hpText=tostring(shownHP(b)).." / "..tostring(maxHP(b))
    printText(hpText,x+55*s,y+21.8*s,4.4*s,textColor,"right",53*s)
  end)
end

-- -------------------------------------------------------------------------
-- Responsive command + dialogue panels
-- -------------------------------------------------------------------------

local function battleMenuScale()
  local sw,sh=love.graphics.getDimensions()
  local raw=math.min(sw/1280,sh/720)

  -- Preserve the established v0.1 size through common 1080p displays.
  if raw <= 1.5 then
    return clamp(raw,0.68,1.18)
  end

  -- Above 1080p, continue scaling instead of freezing at the old 1.18 cap.
  -- 1440p lands around 1.55; 4K around 2.30.
  return clamp(1.18 + (raw-1.5)*0.75,1.18,2.30)
end

local function commandGeometry()
  local sw, sh = love.graphics.getDimensions()
  local u = battleMenuScale()

  local w = clamp(600*u, 390, 1380)
  local h = clamp(210*u, 145, 485)
  local margin = clamp(24*u, 14, 56)

  return { x=sw-w-margin, y=sh-h-margin, w=w, h=h, u=u }
end

local function dialogueGeometry()
  local sw, sh = love.graphics.getDimensions()

  -- Dialogue uses the same bottom footprint as the command panel but is wider.
  local w = clamp(sw * 0.58, 650, 1040)
  local h = clamp(sh * 0.118, 96, 128)
  local margin = clamp(sw * 0.018, 20, 36)

  return { x=margin, y=sh-h-margin, w=w, h=h }
end


local function drawPanelBase(rect)
  local g = love.graphics

  g.setColor(0.02,0.03,0.04,0.42)
  roundedRect("fill", rect.x+8, rect.y+10, rect.w, rect.h, 17)

  g.setColor(0.95,0.95,0.92,0.98)
  roundedRect("fill", rect.x, rect.y, rect.w, rect.h, 15)

  g.setLineWidth(2.5)
  g.setColor(0.18,0.21,0.25,0.95)
  roundedRect("line", rect.x+1.25, rect.y+1.25, rect.w-2.5, rect.h-2.5, 14)
end

local function drawCommandMenu(battle)
  if not (battle and battle.phase == "menu" and not battle.safari
      and not battle.demo) then return end

  local rect = commandGeometry()
  drawPanelBase(rect)

  local g = love.graphics
  local u = rect.u or battleMenuScale()
  local pad = 15*u
  local gap = 11*u
  local cellW = (rect.w-pad*2-gap)/2
  local cellH = (rect.h-pad*2-gap)/2

  -- Preserve engine semantics: 1 FIGHT, 2 PKMN, 3 ITEM, 4 RUN.
  local options = {
    {index=1, label="FIGHT",   col=0,row=0},
    {index=2, label="POKEMON", col=1,row=0},
    {index=3, label="BAG",     col=0,row=1},
    {index=4, label="RUN",     col=1,row=1},
  }

  for _, opt in ipairs(options) do
    local x = rect.x+pad+opt.col*(cellW+gap)
    local y = rect.y+pad+opt.row*(cellH+gap)
    local selected = battle.menuIndex == opt.index

    if selected then
      g.setColor(0.16,0.30,0.42,1)
      roundedRect("fill", x,y,cellW,cellH,10*u)
      g.setColor(0.95,0.36,0.17,1)
      roundedRect("fill", x+6*u,y+7*u,5*u,cellH-14*u,2*u)
      printText(opt.label, x+18*u, y+cellH*0.12, cellH*0.43,
                {0.98,0.98,0.96,1}, "center", cellW-28*u)
    else
      g.setColor(0.86,0.87,0.84,1)
      roundedRect("fill", x,y,cellW,cellH,10*u)
      g.setColor(0.97,0.97,0.95,1)
      roundedRect("fill", x+2*u,y+2*u,cellW-4*u,cellH-4*u,8*u)
      printText(opt.label, x+10*u, y+cellH*0.12, cellH*0.43,
                {0.12,0.14,0.16,1}, "center", cellW-20*u)
    end
  end
end

local function drawDialogue(battle)
  if not (battle and battle.phase == "messages") then return end
  if not (battle.current or battle.animPlaying or battle.msgHold
      or #(battle.shown or {}) > 0) then return end

  local rect = dialogueGeometry()
  drawPanelBase(rect)

  local g = love.graphics
  local lines = messageLines(battle)
  local fullLines = messagePageFullLines(battle)
  local textColor = {0.12,0.14,0.16,1}
  local contentW = math.max(1, rect.w-52)
  local visible = math.min(2,#lines)

  local preferred = clamp(rect.h*0.36,34,50)
  local minimum = math.max(18,preferred*0.62)

  -- Font metrics are chosen from the COMPLETE current page, not from the
  -- characters revealed so far. Typewriter progression therefore never
  -- changes font size or line spacing mid-message.
  local innerTop = 10
  local innerBottom = 12
  local innerH = math.max(1,rect.h-innerTop-innerBottom)

  local metricSource=(#fullLines>0 and fullLines or lines)
  local metricKey=tostring(battle.current and battle.current.text or "")
      .."|"..table.concat(metricSource,"\n")

  if not battle.__gen3MetricCache
      or battle.__gen3MetricCache.key~=metricKey then
    local size,glyphH,lineH,blockH=fittedDialogueMetrics(
      metricSource,preferred,minimum,contentW,innerH)
    battle.__gen3MetricCache={
      key=metricKey,size=size,glyphH=glyphH,lineH=lineH,blockH=blockH,
    }
  end

  local metrics=battle.__gen3MetricCache
  local size,glyphH,lineH,blockH=
    metrics.size,metrics.glyphH,metrics.lineH,metrics.blockH

  local x = rect.x+26
  local y = rect.y + innerTop + math.max(0,(innerH-blockH)*0.5)

  -- Clip to the usable interior only. Because blockH was measured from the
  -- actual font, line two can no longer be cut off by the lower border.
  g.setScissor(
    math.floor(rect.x+20),
    math.floor(rect.y+innerTop-2),
    math.floor(rect.w-40),
    math.floor(innerH+4)
  )
  for i=1,visible do
    printText(lines[i],x,y+(i-1)*lineH,size,textColor,
      "left",contentW)
  end
  g.setScissor()

  if (battle.msgWaiting or battle.msgPrompt)
      and battle.frame % 60 < 30 then
    -- clean modern continue marker
    local g = love.graphics
    g.setColor(0.20,0.31,0.42,1)
    local cx = rect.x+rect.w-31
    local cy = rect.y+rect.h-34
    g.polygon("fill", cx,cy, cx+13,cy, cx+6.5,cy+9)
  end
end


-- -------------------------------------------------------------------------
-- Modern move selection
-- -------------------------------------------------------------------------

local function moveGeometry()
  local sw, sh = love.graphics.getDimensions()
  local u = battleMenuScale()

  local w = clamp(720*u, 470, 1660)
  local h = clamp(300*u, 205, 690)
  local margin = clamp(24*u, 14, 56)

  return {
    x = sw - w - margin,
    y = sh - h - margin,
    w = w,
    h = h,
    u = u,
  }
end

local function moveTypeName(def)
  if not def then return "—" end
  local t = def.type or def.moveType or def.damageType
  if type(t) == "table" then
    t = t.name or t.id
  end
  return t and tostring(t):upper() or "—"
end

local function moveMaxPP(def, mv)
  if mv and mv.maxPP then return mv.maxPP end
  if def and def.pp then return def.pp end
  return mv and mv.pp or 0
end

local function drawMoveSelect(battle)
  if not (battle and battle.phase == "moveSelect"
      and battle.player and battle.player.curMoves) then
    return
  end

  local rect = moveGeometry()
  drawPanelBase(rect)

  local moves = battle.player.curMoves
  local u = rect.u or battleMenuScale()
  local pad = 16*u
  local gap = 8*u
  local infoH = 50*u
  local listTop = rect.y + pad
  local listBottom = rect.y + rect.h - pad - infoH - 7*u
  local rowH = (listBottom - listTop - gap * 3) / 4

  local g = love.graphics

  for i = 1, 4 do
    local mv = moves[i]
    local y = listTop + (i - 1) * (rowH + gap)
    local selected = battle.moveIndex == i
    local disabled = battle.player.disabledSlot == i
    local marked = battle.moveSwapIndex == i

    if selected then
      g.setColor(0.16, 0.30, 0.42, 1)
      roundedRect("fill", rect.x + pad, y, rect.w - pad*2, rowH, 9*u)
      g.setColor(0.95, 0.36, 0.17, 1)
      roundedRect("fill", rect.x + pad + 6*u, y + 6*u, 5*u, rowH - 12*u, 2*u)
    else
      g.setColor(0.86, 0.87, 0.84, 1)
      roundedRect("fill", rect.x + pad, y, rect.w - pad*2, rowH, 9)
      g.setColor(0.97, 0.97, 0.95, 1)
      roundedRect("fill", rect.x + pad + 2*u, y + 2*u,
                  rect.w - pad*2 - 4*u, rowH - 4*u, 7*u)
    end

    if mv then
      local def = battle.data.moves[mv.id]
      local label = def and def.name or tostring(mv.id)
      local curPP = mv.pp or 0
      local maxPP = moveMaxPP(def, mv)

      local textColor = selected and {0.98,0.98,0.96,1}
                                  or {0.12,0.14,0.16,1}
      if disabled then
        textColor = selected and {1.00,0.78,0.72,1}
                             or {0.62,0.30,0.26,1}
      end

      local nameSize = clamp(rowH * 0.40, 16*u, 34*u)
      printText(label, rect.x + pad + 18*u, y + rowH*0.13,
                nameSize, textColor)

      local ppText = ("%d / %d"):format(curPP, maxPP)
      printText(ppText, rect.x + rect.w - pad - 138*u, y + rowH*0.15,
                clamp(rowH*0.30, 13*u, 26*u), textColor, "right", 126*u)

      if marked then
        printText("MOVE", rect.x + rect.w - pad - 215*u, y + rowH*0.17,
                  clamp(rowH*0.25, 11*u, 21*u),
                  selected and {0.98,0.84,0.34,1} or {0.64,0.46,0.08,1})
      end
    else
      printText("—", rect.x + pad + 18*u, y + rowH*0.13,
                clamp(rowH*0.34, 14*u, 28*u),
                selected and {0.98,0.98,0.96,0.5}
                         or {0.35,0.36,0.37,0.55})
    end
  end

  local selectedMove = moves[battle.moveIndex]
  if selectedMove then
    local def = battle.data.moves[selectedMove.id]
    local typeText = "TYPE  " .. moveTypeName(def)
    local ppText = ("PP  %d / %d"):format(
      selectedMove.pp or 0, moveMaxPP(def, selectedMove))

    local infoY = rect.y + rect.h - pad - infoH
    g.setColor(0.90,0.91,0.89,1)
    roundedRect("fill", rect.x + pad, infoY, rect.w - pad*2, infoH, 9*u)

    printText(typeText, rect.x + pad + 16*u, infoY + 7*u,
              23*u, {0.20,0.22,0.24,1})
    printText(ppText, rect.x + rect.w - pad - 190*u, infoY + 7*u,
              23*u, {0.20,0.22,0.24,1}, "right", 175*u)

    if battle.player.disabledSlot == battle.moveIndex then
      printText("DISABLED", rect.x + rect.w/2 - 62*u, infoY + 10*u,
                17*u, {0.70,0.20,0.16,1}, "center", 124*u)
    elseif selectedMove.pp <= 0 then
      printText("NO PP", rect.x + rect.w/2 - 54*u, infoY + 10*u,
                17*u, {0.70,0.20,0.16,1}, "center", 108*u)
    end
  end
end


-- -------------------------------------------------------------------------
-- Cohesive overworld UI alpha
-- -------------------------------------------------------------------------


-- Same Plain Pixel source as the battle HUD, but sized for the native 160x144
-- menu canvas so overworld UI and battle UI read as one continuous system.
local function owFont(size)
  size = math.max(7, math.floor(size + 0.5))
  if overworldFonts[size] then return overworldFonts[size] end
  local ok, f = pcall(love.graphics.newFont,
    EngineFont.PLAINPIXEL, size, "normal")
  if not ok or not f then
    local fallback = love.graphics.getFont()
    overworldFonts[size] = fallback
    return fallback
  end
  if f.setFilter then pcall(f.setFilter, f, "nearest", "nearest") end
  overworldFonts[size] = f
  return f
end

local function owText(text, x, y, size, color, align, width)
  local g = love.graphics
  local f = owFont(size)
  local old = g.getFont()
  g.setFont(f)

  text = tostring(text or "")
  color = color or {0.08,0.08,0.08,1}

  -- Integer-aligned, single-pass text for maximum menu clarity.
  x = math.floor(x + 0.5)
  y = math.floor(y + 0.5)

  if width then
    g.setColor(color)
    g.printf(text, x, y, math.floor(width + 0.5), align or "left")
  else
    g.setColor(color)
    g.print(text, x, y)
  end

  if old then g.setFont(old) end
  g.setColor(1,1,1,1)
end


local function owStatus(mon)
  if (mon.hp or 0) <= 0 then return "FNT" end
  if mon.status then return tostring(mon.status):upper() end
  return nil
end


-- Restrained FireRed/LeafGreen-style overworld panel.
-- Unlike the battle HUD, START/Bag intentionally avoid heavy beveling/cards.
local function frlgMenuPanel(x, y, w, h)
  local g = love.graphics

  -- Tiny shadow, then green/olive edge, then warm white face.
  g.setColor(0.10,0.16,0.13,0.45)
  g.rectangle("fill", x+2, y+2, w, h)

  g.setColor(0.20,0.20,0.18,1)
  g.rectangle("fill", x, y, w, h)

  g.setColor(0.985,0.982,0.95,1)
  g.rectangle("fill", x+2, y+2, w-4, h-4)

  -- Light inner line gives the flat GBA panel a little HD definition.
  g.setColor(1.0,0.995,0.96,1)
  g.rectangle("line", x+3, y+3, w-6, h-6)

  g.setColor(1,1,1,1)
end

local function frlgSelection(x, y, w, h)
  local g = love.graphics
  -- FRLG-style restrained selection: charcoal field, white text.
  g.setColor(0.13,0.13,0.12,1)
  g.rectangle("fill", x, y, w, h)

  -- Thin light edge instead of a colored accent stripe.
  g.setColor(0.86,0.86,0.82,1)
  g.rectangle("line", x+0.5, y+0.5, w-1, h-1)

  g.setColor(1,1,1,1)
end

local function installOverworldUI(mod)
  if overworldUIPatched then return end
  overworldUIPatched = true

  -- Mark only the real START menu instance. Menu is generic and used in many
  -- places; the custom renderer branches exclusively on this marker.
  local originalStartNew = StartMenu.new
  StartMenu.new = function(game)
    local menu = originalStartNew(game)
    menu.__gen3uiStart = true
    return menu
  end

  local originalMenuDraw = Menu.draw
  Menu.draw = function(self)
    if self.__gen3uiStart then
      if not featureEnabled("revampedOverworldMenus") then
        activeStartMenu = nil
        return originalMenuDraw(self)
      end
      activeStartMenu = self
      return
    end

    if featureEnabled("revampedPokemonPC") then
      if self.__gen3uiPCAccess then
        activePCAccessMenu=self
        activePCMenu=nil
        activePCActionMenu=nil
        return
      elseif self.__gen3uiPCMain then
        activePCMenu=self
        activePCAccessMenu=nil
        activePCActionMenu=nil
        return
      elseif self.__gen3uiPCAction then
        activePCActionMenu=self
        return
      end
    end

    -- Generic Menu is also used for Bag item actions such as USE / TOSS.
    if featureEnabled("revampedOverworldMenus") then
      local bag = bagStateForMenu(self.game)
      if bag then
        activeBagActionMenu = self
        return
      end
    end

    activeBagActionMenu = nil
    return originalMenuDraw(self)
  end

  -- Mark Bag-created ListMenu instances so shops/dex/PC lists remain vanilla.
  local originalBagNew = BagMenu.new
  BagMenu.new = function(game, opts)
    local list = originalBagNew(game, opts)
    list.__gen3uiBag = true
    return list
  end

  local originalListDraw = ListMenu.draw
  ListMenu.draw = function(self)
    if self.__gen3uiPCList then
      if featureEnabled("revampedPokemonPC") then
        activePCList=self
        activeBagMenu=nil
        return
      end
      activePCList=nil
      return originalListDraw(self)
    end

    if not featureEnabled("revampedOverworldMenus") then
      activeBagMenu=nil
      return originalListDraw(self)
    end

    if self.__gen3uiBag then
      activeBagMenu=self
      activePCList=nil
      return
    end

    activeBagMenu=nil
    activePCList=nil
    return originalListDraw(self)
  end

  -- TM/HM target picking should remain on the Party screen through the
  -- teach/replace-move flow, matching the original games. PartyMenu already
  -- supports this behavior through keepOpen; opt TM/HM pickers into it.
  local originalPartyNew = PartyMenu.new
  PartyMenu.new = function(game, opts)
    opts = opts or {}
    if opts.tmhm then
      opts.keepOpen = true
    end
    local party = originalPartyNew(game, opts)
    if opts.tmhm then
      party.__gen3uiKeepTMBackground = true
      activeTMParty = party
      -- The Pokémon screen now owns the background; Bag handoff is complete.
      activeBagActionMenu = nil
    end
    return party
  end

  -- Track MoveLearnMenu from creation so native prompt pages can retain the
  -- revamped Party screen underneath before actual move selection begins.
  local originalMoveLearnNew = MoveLearnMenu.new
  MoveLearnMenu.new = function(game, mon, newMoveId, onDone)
    -- Preserve the engine constructor EXACTLY. Dropping newMoveId/onDone corrupts
    -- the state and crashes once actual move replacement begins.
    local menu = originalMoveLearnNew(game, mon, newMoveId, onDone)
    if activeTMParty and menu and menu.mon and canIntegrateMoveLearn(game, menu) then
      activeTMPromptFlow = menu
    end
    return menu
  end

  -- TM move replacement uses the engine's native MoveLearnMenu INPUT/LOGIC,
  -- but during a kept-open TM Party flow its standalone draw is suppressed.
  -- The active selection is rendered inside the Party detail panel instead.
  local originalMoveLearnDraw = MoveLearnMenu.draw
  MoveLearnMenu.draw = function(self)
    if canIntegrateMoveLearn(self.game, self) then
      activeTMPromptFlow = self

      -- Preserve all native prompt/dialogue presentation. Only suppress the
      -- standalone MoveLearnMenu once the engine naturally enters selection.
      if self.selecting then
        activeMoveLearn = self
        return
      end
    end

    if activeMoveLearn == self then activeMoveLearn = nil end
    return originalMoveLearnDraw(self)
  end

  -- Pokémon selection: full visual replacement, existing input/state unchanged.
  -- Uses Gen1Recomp's own icon renderer so sprite/mon mods remain compatible.
  local originalPartyDraw = PartyMenu.draw
  PartyMenu.draw = function(self)
    if not featureEnabled("revampedPokemonMenu") then
      activeParty = nil
      activeTMParty = nil
      activeMoveLearn = nil
      activeTMPromptFlow = nil
      return originalPartyDraw(self)
    end
    activeParty = self
  end

  if mod and mod.log then
    pcall(function()
      mod.log("info", "Gen 3 Inspired UI Overhaul: overworld START/Bag/Party UI alpha active")
    end)
  end
end


-- -------------------------------------------------------------------------
-- Final-pass FRLG overworld menus
-- -------------------------------------------------------------------------

local function uiTopState(game, state)
  if not (game and game.stack and game.stack.states and state) then return false end
  local top = (game.stack.top and game.stack:top()) or game.stack.states[#game.stack.states]
  return top == state
end


local function findBagStateInStack(game)
  return bagStateForMenu(game)
end

local function finalCanvas()
  local sw, sh = love.graphics.getDimensions()
  local raw = math.min(sw / 160, sh / 144)
  local scale = math.floor(raw)
  if scale < 1 then scale = raw end
  local ox = math.floor((sw - 160*scale) * 0.5 + 0.5)
  local oy = math.floor((sh - 144*scale) * 0.5 + 0.5)
  return ox, oy, scale
end

local function finalText(text, lx, ly, logicalSize, color, ox, oy, sc, align, logicalWidth)
  local sx = math.floor(ox + lx*sc + 0.5)
  local sy = math.floor(oy + ly*sc + 0.5)
  local pxSize = math.max(4, math.floor(logicalSize*sc + 0.5))
  local pxWidth = logicalWidth and math.floor(logicalWidth*sc + 0.5) or nil

  love.graphics.push("all")
  love.graphics.origin()
  printText(text, sx, sy, pxSize, color, align, pxWidth)
  if pxSize >= 10 then
    printText(text, sx+1, sy, pxSize, color, align, pxWidth)
  end
  love.graphics.pop()
end

local function finalTextWidth(text, logicalSize, sc)
  local pxSize = math.max(4, math.floor(logicalSize*sc + 0.5))
  return font(pxSize):getWidth(tostring(text or "")) / math.max(sc,0.001)
end

local function drawStartFinal(game, state)
  local g = love.graphics
  local ox,oy,sc = finalCanvas()
  local visible = (state.maxVisible and math.min(state.maxVisible, #state.items)) or #state.items

  local rowH = 12
  local w = 60
  local h = visible*rowH + 8
  local x = 96
  local y = math.max(3, math.floor((144-h)/2))

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  g.setColor(0.05,0.05,0.05,0.35)
  g.rectangle("fill",x+2,y+2,w,h)

  g.setColor(0.08,0.08,0.07,1)
  g.rectangle("fill",x,y,w,h)
  g.setColor(0.99,0.985,0.95,1)
  g.rectangle("fill",x+2,y+2,w-4,h-4)

  drawUnifiedBorder(x,y,w,h,0)

  for row=1,visible do
    local item = state.items[state.scroll + row]
    if not item then break end
    local ry = y + 4 + (row-1)*rowH
    if (state.scroll + row) == state.index then
      g.setColor(0.10,0.10,0.09,1)
      g.rectangle("fill",x+4,ry,w-8,rowH-1)
    end
  end
  g.pop()

  for row=1,visible do
    local item = state.items[state.scroll + row]
    if not item then break end
    local ry = y + 4 + (row-1)*rowH
    local selected = (state.scroll + row) == state.index
    finalText(item.label,x+9,ry+1,5,
      selected and {1,1,1,1} or {0.04,0.04,0.04,1},
      ox,oy,sc)
  end
end


local function drawBagActionFinal(game, state)
  local g = love.graphics
  local ox,oy,sc = finalCanvas()

  local items = state.items or {}
  local count = #items
  if count < 1 then return end

  local rowH = 12
  local w = 48
  local h = count*rowH + 8
  local x = 107
  local y = math.max(5, 105 - h)

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  g.setColor(0.05,0.05,0.05,0.35)
  g.rectangle("fill",x+2,y+2,w,h)

  g.setColor(0.08,0.08,0.07,1)
  g.rectangle("fill",x,y,w,h)

  g.setColor(0.99,0.985,0.95,1)
  g.rectangle("fill",x+2,y+2,w-4,h-4)

  drawUnifiedBorder(x,y,w,h,0)

  for i=1,count do
    local ry = y + 4 + (i-1)*rowH
    if i == (state.index or 1) then
      g.setColor(0.10,0.10,0.09,1)
      g.rectangle("fill",x+4,ry,w-8,rowH-1)
    end
  end

  g.pop()

  for i=1,count do
    local item = items[i]
    local label = item and (item.label or item.text or tostring(item)) or ""
    local ry = y + 4 + (i-1)*rowH
    local selected = i == (state.index or 1)

    finalText(label,x+9,ry+1,5,
      selected and {1,1,1,1} or {0.04,0.04,0.04,1},
      ox,oy,sc)
  end
end

local function drawBagFinal(game, state)
  local g = love.graphics
  local ox,oy,sc = finalCanvas()

  local x,y,w,h = 5,5,150,134
  local headerH = 17
  local footerH = 24

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  g.setColor(0.08,0.08,0.07,1)
  g.rectangle("fill",x,y,w,h)
  g.setColor(0.99,0.985,0.95,1)
  g.rectangle("fill",x+2,y+2,w-4,h-4)

  drawUnifiedBorder(x,y,w,h,0)
  g.setColor(0.72,0.70,0.62,1)
  g.rectangle("fill",x+6,y+headerH,w-12,1)
  g.rectangle("fill",x+6,y+h-footerH,w-12,1)

  local rows = math.min(state.rows or 7, 7)
  local listY = y + headerH + 4
  local rowH = 12

  for row=1,rows do
    local i = state.scroll + row
    local item = state.items[i]
    if not item then break end
    local ry = listY + (row-1)*rowH
    if i == state.index then
      g.setColor(0.10,0.10,0.09,1)
      g.rectangle("fill",x+7,ry,w-14,rowH-1)
    end
  end
  g.pop()

  finalText(Strings("BAG"),x+9,y+5,6,{0.04,0.04,0.04,1},ox,oy,sc)

  if state.footer then
    local fw = finalTextWidth(state.footer,4,sc)
    finalText(state.footer,x+w-9-fw,y+6,4,{0.12,0.12,0.11,1},ox,oy,sc)
  end

  if #state.items == 0 then
    finalText(Strings("Nothing here."),x+12,y+32,5,{0.04,0.04,0.04,1},ox,oy,sc)
  else
    local rows = math.min(state.rows or 7,7)
    local listY = y + headerH + 4
    local rowH = 12

    for row=1,rows do
      local i = state.scroll + row
      local item = state.items[i]
      if not item then break end
      local ry = listY + (row-1)*rowH
      local selected = i == state.index
      local col = selected and {1,1,1,1} or {0.04,0.04,0.04,1}

      finalText(item.label,x+12,ry+1,5,col,ox,oy,sc)

      if item.right then
        local rw = finalTextWidth(item.right,4,sc)
        finalText(item.right,x+w-11-rw,ry+2,4,col,ox,oy,sc)
      end
    end
  end

  local current = state.items and state.items[state.index]
  local help = ""
  if current then help = current.description or current.desc or current.help or "" end
  if help == "" and state.description then help = state.description end
  if help ~= "" then
    finalText(help,x+10,y+h-footerH+5,4,{0.12,0.12,0.11,1},
      ox,oy,sc,"left",w-20)
  end
end

-- -------------------------------------------------------------------------
-- Final-pass FRLG Party screen
-- -------------------------------------------------------------------------

local function partyTopState(game, party)
  if not (game and game.stack and game.stack.states and party) then return false end
  local top = (game.stack.top and game.stack:top()) or game.stack.states[#game.stack.states]
  return top == party
end


local function partyInStack(game, party)
  if not (game and game.stack and game.stack.states and party) then return false end
  for _,state in ipairs(game.stack.states) do
    if state == party then return true end
  end
  return false
end

local function partyShouldRenderBehindTM(game, party)
  if not party then return false end
  if not party.keepOpen then return false end
  if not (party.tmhm or party.__gen3uiKeepTMBackground) then return false end
  return partyInStack(game, party)
end


-- -------------------------------------------------------------------------
-- Selected Pokémon battle portrait
-- -------------------------------------------------------------------------
-- Resolve through src.pokemon.Sprites.path with kind="battle". This is the
-- engine's live compatibility seam for battle-sprite replacement mods, so
-- Crystal-style packs and other pokemon.sprite hooks carry into Party without
-- this mod knowing anything about individual packs.

local partyBattleSpriteCache = {}

local function partyBattlePaletteKey(data, species)
  local colors = PaletteFX.monPal(data, species)
  if not colors then return "none", nil end

  local name = PaletteFX.monPalName(data, species) or "MON"
  if PaletteFX.usesGbcPack() then name = "redpp:" .. name end
  return name, colors
end

local function partyBattleSpriteImage(game, mon)
  if not (game and game.data and mon and mon.species) then return nil end

  -- Resolve on EVERY draw. Battle-art mods can switch generation/variant while
  -- the game is running; caching the resolver result itself would pin Party to
  -- whichever sprite was active when the menu first opened.
  local path, trueColor = PokemonSprites.path(
    game.data, mon.species, "front",
    { mon = mon, kind = "battle" }
  )
  if not path then return nil end

  local palName, colors = partyBattlePaletteKey(game.data, mon.species)
  local key = path .. "|" .. (trueColor and "truecolor" or palName)

  -- Cache only the final image BY THE RESOLVED PATH. A changed Battle Art path
  -- therefore selects a different cache entry immediately.
  local cached = partyBattleSpriteCache[key]
  if cached then return cached end

  local image = nil

  -- True-color sprite packs must bypass the 4-shade recolor contract exactly
  -- as they do in BattleState.
  if trueColor or not colors or not (love.image and love.image.newImageData) then
    image = Assets.image(path)
  else
    -- Match BattleState's four-shade species palette mapping.
    local id = Assets.imageData(path)
    if id then
      id:mapPixel(function(_, _, r, g, b, a)
        if a == 0 then return r, g, b, a end
        local col = r > 0.83 and colors[1]
          or r > 0.5 and colors[2]
          or r > 0.17 and colors[3]
          or colors[4]
        return col[1] / 255, col[2] / 255, col[3] / 255, a
      end)
      image = love.graphics.newImage(id)
    end
  end

  if image and image.setFilter then
    image:setFilter("nearest", "nearest")
  end

  partyBattleSpriteCache[key] = image
  return image
end

local function drawSelectedBattleSprite(game, mon, x, y, w, h)
  local img = partyBattleSpriteImage(game, mon)
  if not img then return false end

  local iw, ih = img:getDimensions()
  if not iw or not ih or iw <= 0 or ih <= 0 then return false end

  -- Battle Art / Gen-V packs may expose an animation atlas rather than a
  -- single square frame. For a Party portrait we intentionally use frame 1.
  -- Common horizontal and vertical strips are detected conservatively.
  local fw, fh = iw, ih
  if iw >= ih * 2 and iw % ih == 0 then
    fw = ih
  elseif ih >= iw * 2 and ih % iw == 0 then
    fh = iw
  end

  local scale = math.min(w / fw, h / fh)
  if scale <= 0 then return false end

  local dw, dh = fw * scale, fh * scale
  local dx = x + (w - dw) * 0.5
  local dy = y + (h - dh) * 0.5

  love.graphics.setColor(1,1,1,1)
  if fw ~= iw or fh ~= ih then
    local quad = love.graphics.newQuad(0, 0, fw, fh, iw, ih)
    love.graphics.draw(img, quad, dx, dy, 0, scale, scale)
  else
    love.graphics.draw(img, dx, dy, 0, scale, scale)
  end
  love.graphics.setColor(1,1,1,1)
  return true
end

local function partyLogicalCanvas()
  local sw, sh = love.graphics.getDimensions()
  local raw = math.min(sw / 160, sh / 144)

  -- Integer scaling preserves the battle font's pixel structure.
  -- Only fall back to fractional scaling on very small windows.
  local scale = math.floor(raw)
  if scale < 1 then scale = raw end

  local ox = math.floor((sw - 160*scale) * 0.5 + 0.5)
  local oy = math.floor((sh - 144*scale) * 0.5 + 0.5)
  return ox, oy, scale
end

local function partySlotPanel(x,y,w,h,selected)
  local g = love.graphics
  g.setColor(0.14,0.14,0.13,1)
  roundedRect("fill",x,y,w,h,3)
  g.setColor(selected and {0.975,0.955,0.88,1} or {0.99,0.985,0.955,1})
  roundedRect("fill",x+2,y+2,w-4,h-4,2)
  if selected then
    g.setColor(0.72,0.58,0.28,1)
    roundedRect("line",x+3,y+3,w-6,h-6,2)
  end
end

local function partyHPBarFinal(x,y,w,mon)
  local g = love.graphics
  local maxhp = math.max(1, mon.stats and mon.stats.hp or 1)
  local ratio = clamp((mon.hp or 0)/maxhp,0,1)
  g.setColor(0.10,0.10,0.09,1)
  roundedRect("fill",x,y,w,4,1.5)
  g.setColor(0.78,0.76,0.63,1)
  roundedRect("fill",x+1,y+1,w-2,2,1)
  local fill = (w-2)*ratio
  if (mon.hp or 0)>0 then fill = math.max(1,fill) end
  if fill>0 then
    local r,gg,b,a = hpColor(ratio)
    g.setColor(r,gg,b,a)
    roundedRect("fill",x+1,y+1,fill,2,1)
  end
end


-- Party UI deliberately uses the exact battle typography implementation.
-- These wrappers exist only so Party layout code remains readable.
local function partyTextWidth(text, size)
  -- Convert the full-resolution battle-font width back into logical Party units
  -- so existing FRLG layout calculations (right alignment, columns) still work.
  local sc = math.max(0.001, partyRenderScale or 1)
  -- Global readability polish: a deliberately small bump, not a redesign.
  local pxSize = math.max(4, math.floor(size * sc * 1.06 + 0.5))
  return font(pxSize):getWidth(tostring(text or "")) / sc
end

local function partyText(text, x, y, size, color, align, width)
  -- Critical difference from previous builds:
  -- Party geometry is inside a scaled 160x144 transform, but text is NOT.
  -- Drop to screen coordinates and call the exact battle printText() renderer.
  local g = love.graphics
  local sc = math.max(0.001, partyRenderScale or 1)

  local sx = math.floor((partyRenderOX or 0) + x * sc + 0.5)
  local sy = math.floor((partyRenderOY or 0) + y * sc + 0.5)
  local pxSize = math.max(4, math.floor(size * sc + 0.5))
  local pxWidth = width and math.floor(width * sc + 0.5) or nil

  g.push("all")
  g.origin()
  printText(text, sx, sy, pxSize, color, align, pxWidth)
  g.pop()
end


local function partyExpRatio(game, mon)
  if not (game and game.data and mon) then return 0 end
  local def = game.data.pokemon and game.data.pokemon[mon.species]
  if not def then return 0 end

  local cap = (game.data.constants and game.data.constants.levelCap) or 100
  local level = math.max(1, math.floor(mon.level or 1))
  if level >= cap then return 1 end

  local rates = game.data.growth_rates
  local okCur, cur = pcall(Growth.expForLevel, def.growthRate, level, rates)
  local okNext, nxt = pcall(Growth.expForLevel, def.growthRate, level + 1, rates)
  if not okCur or not okNext or not cur or not nxt or nxt <= cur then
    return 0
  end

  return clamp(((mon.exp or cur) - cur) / (nxt - cur), 0, 1)
end

local function drawPartyExpBar(game, mon, x, y, w)
  local g = love.graphics
  local ratio = partyExpRatio(game, mon)

  g.setColor(0.10,0.18,0.24,1)
  roundedRect("fill", x, y, w, 4, 1.5)

  g.setColor(0.14,0.28,0.38,1)
  roundedRect("fill", x+1, y+1, w-2, 2, 1)

  local fill = (w-2) * ratio
  if fill > 0 then
    g.setColor(0.08,0.48,0.96,1)
    roundedRect("fill", x+1, y+1, fill, 2, 1)
  end

  g.setColor(1,1,1,1)
end

local function partyMoveName(game, move)
  if not move then return "---" end

  local id = move.id or move.move or move.name or move
  if type(id) == "string" then
    local def = game.data.moves and game.data.moves[id]
    return (def and def.name) or id
  end

  local def = game.data.moves and game.data.moves[id]
  return (def and def.name) or tostring(id or "---")
end

local function partyMovePP(game, move)
  if not move then return "" end
  local pp = move.pp
  local maxpp = move.maxPP or move.ppMax

  if maxpp == nil then
    local id = move.id or move.move or move.name or move
    local def = game.data.moves and game.data.moves[id]
    maxpp = def and def.pp
  end

  if pp ~= nil and maxpp ~= nil then
    return tostring(pp).."/"..tostring(maxpp)
  elseif maxpp ~= nil then
    return tostring(maxpp)
  end
  return ""
end

local function partyStat(mon, ...)
  local stats = mon and mon.stats or {}
  local keys = {...}
  for _,key in ipairs(keys) do
    local v = stats[key]
    if v ~= nil then return v end
  end
  return "-"
end


local function drawPartyMoveReplace(game, mon, x, y, w, h, learn)
  if not (mon and learn) then return end

  local g = love.graphics
  local moves = mon.moves or {}
  local moveId = learn.newMoveId
  local newDef = moveId and game.data.moves[moveId] or nil
  local newName = (newDef and newDef.name) or tostring(moveId or "MOVE")

  -- Repaint the ENTIRE information region every frame. This is intentionally
  -- opaque so no text from the normal details panel or native MoveLearnMenu
  -- can remain visible underneath the integrated replacement interface.
  local areaX = x + 6
  local areaY = y + 63
  local areaW = w - 12
  local areaH = h - 67

  g.setColor(0.99,0.975,0.90,1)
  g.rectangle("fill",areaX,areaY,areaW,areaH)

  g.setColor(0.70,0.68,0.59,1)
  g.rectangle("fill",x+7,y+64,w-14,1)

  partyText("REPLACE MOVE",x+8,y+65,3,{0.16,0.16,0.14,1})

  -- Incoming move occupies a fixed header row.
  partyText("NEW",x+8,y+70,2,{0.46,0.34,0.10,1})
  local incoming = newName
  if #incoming > 12 then incoming = incoming:sub(1,11).."." end
  partyText(incoming,x+20,y+69,3,{0.06,0.06,0.06,1})

  -- Four fixed rows, with enough vertical separation that no fifth/cancel
  -- state can collide with move text.
  local moveTop = y + 76
  local rowH = 6
  local rowX = x + 7
  local rowW = w - 14
  local ppRight = x + w - 7
  local selected = math.max(1,math.min(learn.index or 1,#moves+1))

  for i=1,4 do
    local mv = moves[i]
    local my = moveTop + (i-1)*rowH
    local isSelected = (i == selected)

    if isSelected then
      g.setColor(0.10,0.10,0.09,1)
      roundedRect("fill",rowX,my-1,rowW,6,1)
    end

    if mv then
      local name = partyMoveName(game,mv)
      if #name > 12 then name = name:sub(1,11).."." end
      local col = isSelected and {1,1,1,1} or {0.06,0.06,0.06,1}
      partyText(name,x+10,my,2,col)

      local pp = partyMovePP(game,mv)
      if pp ~= "" then
        local pw = partyTextWidth(pp,2)
        partyText(pp,ppRight-pw,my,2,
          isSelected and {1,1,1,1} or {0.20,0.20,0.18,1})
      end
    else
      partyText("---",x+10,my,2,
        isSelected and {1,1,1,1} or {0.38,0.38,0.34,1})
    end
  end

  -- No CANCEL label is ever drawn in this panel. The native fifth cursor
  -- position still exists logically and is represented only by the bottom prompt.
  g.setColor(1,1,1,1)
end

local function drawPartyDetails(game, mon, x, y, w, h)
  if not mon then return end

  local g = love.graphics
  local moves = mon.moves or {}

  -- Details begin directly under EXP.
  local detailDividerY = y + 64
  g.setColor(0.70,0.68,0.59,1)
  g.rectangle("fill", x+7, detailDividerY, w-14, 1)

  partyText("MOVES", x+8, detailDividerY+2, 3, {0.16,0.16,0.14,1})

  -- Compact four-row move block.
  local moveTop = detailDividerY + 7
  local moveRowH = 4
  local ppRight = x + w - 7

  for i=1,4 do
    local m = moves[i]
    local my = moveTop + (i-1)*moveRowH
    local name = partyMoveName(game,m)
    local pp = partyMovePP(game,m)

    if #name > 12 then
      name = name:sub(1,11).."."
    end

    partyText(name, x+8, my, 3, {0.06,0.06,0.06,1})

    if pp ~= "" then
      local pw = partyTextWidth(pp, 2)
      partyText(pp, ppRight-pw, my, 2, {0.20,0.20,0.18,1})
    end
  end

  -- Stats stay in a fixed footer, isolated from moves.
  local statsDividerY = y + h - 13
  g.setColor(0.74,0.72,0.64,1)
  g.rectangle("fill", x+7, statsDividerY, w-14, 1)

  local stats = {
    {"ATK", partyStat(mon,"attack","atk")},
    {"DEF", partyStat(mon,"defense","def")},
    {"SPD", partyStat(mon,"speed","spd")},
    {"SPC", partyStat(mon,"special","spc","specialAttack")},
  }

  local innerX = x + 7
  local innerW = w - 14
  local colW = innerW / 4
  local labelY = statsDividerY + 1
  local valueY = statsDividerY + 4

  for i,s in ipairs(stats) do
    local colX = innerX + (i-1)*colW
    local label = s[1]
    local value = tostring(s[2])

    local lw = partyTextWidth(label, 2)
    local vw = partyTextWidth(value, 3)

    partyText(label, colX + (colW-lw)/2, labelY, 2, {0.25,0.25,0.22,1})
    partyText(value, colX + (colW-vw)/2, valueY, 3, {0.06,0.06,0.06,1})
  end
end


local function pokedexSeenCount(save)
  -- Gen1Recomp's authoritative Pokédex save structure is:
  --   save.pokedex.seen
  --   save.pokedex.owned
  -- The UI should mirror the game's actual Pokédex flags directly rather than
  -- infer progress from party/storage contents or alternate field names.
  local seen=save and save.pokedex and save.pokedex.seen
  if type(seen)~="table" then return 0 end

  local count=0
  for _ in pairs(seen) do
    count=count+1
  end
  return count
end

local function pokedexOwnedCount(save)
  local owned=save and save.pokedex and save.pokedex.owned
  if type(owned)~="table" then return 0 end
  local count=0
  for _ in pairs(owned) do count=count+1 end
  return count
end

local function totalStoredPokemon(save)
  if not save then return 0 end

  -- Prefer the canonical Boxes container when available, but remain
  -- defensive for save-format/mod variations.
  local boxes=save.boxes
      or save.pcBoxes
      or save.storage
      or save.pokemonBoxes

  if type(boxes)=="table" then
    local total=0
    for _,box in pairs(boxes) do
      if type(box)=="table" then
        -- Some formats wrap entries under .pokemon/.mons/.slots.
        local entries=box.pokemon or box.mons or box.slots or box
        if type(entries)=="table" then
          for _,mon in pairs(entries) do
            if type(mon)=="table" and (mon.species or mon.nickname or mon.level) then
              total=total+1
            end
          end
        end
      end
    end
    return total
  end

  -- Last-resort: current active box only, better than showing nonsense.
  local ok,active=pcall(Boxes.active,save)
  if ok and type(active)=="table" then return #active end

  return 0
end

local function pcSelectedMon(game,state)
  if not state then return nil end

  if state.__gen3uiPCList then
    local title=tostring(state.title or ""):upper()
    local source=nil
    if title=="PARTY (DEPOSIT)" then
      source=game.save and game.save.party or {}
    elseif title:find("(WITHDRAW)",1,true) or title:find("(RELEASE)",1,true) then
      source=Boxes.active(game.save)
    end
    if source then
      local index=math.max(1,math.min(state.index or 1,#source))
      return source[index]
    end
  end

  return nil
end

local function drawPCBackground(game,title,subtitle)
  local g=love.graphics
  g.setColor(0.94,0.93,0.87,1)
  g.rectangle("fill",0,0,160,144)

  g.setColor(0.08,0.08,0.08,1)
  g.rectangle("fill",4,4,152,16)
  g.setColor(0.99,0.985,0.955,1)
  g.rectangle("fill",5,5,150,14)
  partyText(title or "POKéMON PC",10,6,6,{0.06,0.06,0.06,1})

  if subtitle and subtitle~="" then
    local tw=partyTextWidth(subtitle,3)
    partyText(subtitle,151-tw,9,3,{0.26,0.26,0.23,1})
  end
end

local function drawPCAccessFinal(game,state)
  local ox,oy,sc=partyLogicalCanvas()
  local g=love.graphics
  partyRenderOX,partyRenderOY,partyRenderScale=ox,oy,sc

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  local items=state.items or {}
  local count=#items
  local w=64
  local h=10+count*14
  local x=92
  local y=10

  g.setColor(0.08,0.08,0.08,0.35)
  roundedRect("fill",x+2,y+2,w,h,3)
  g.setColor(0.99,0.985,0.95,1)
  roundedRect("fill",x,y,w,h,3)
  g.setColor(0.12,0.12,0.11,1)
  g.setLineWidth(1.5)
  roundedRect("line",x,y,w,h,3)

  for i,item in ipairs(items) do
    local yy=y+6+(i-1)*14
    local selected=i==(state.index or 1)
    if selected then
      g.setColor(0.10,0.10,0.10,1)
      roundedRect("fill",x+5,yy-1,w-10,10,2)
      g.setColor(0.72,0.58,0.30,1)
      roundedRect("line",x+6,yy,w-12,8,2)
    end
    local label=tostring(item.label or ""):gsub("<PK><MN>","POKéMON")
    partyText(label,x+10,yy,4,
      selected and {0.98,0.97,0.92,1} or {0.06,0.06,0.06,1})
  end

  local bx,by,bw,bh=4,118,152,22
  g.setColor(0.08,0.08,0.08,1)
  g.rectangle("fill",bx,by,bw,bh)
  g.setColor(0.99,0.985,0.95,1)
  g.rectangle("fill",bx+2,by+2,bw-4,bh-4)
  drawUnifiedBorder(bx,by,bw,bh,0)
  partyText("Access whose PC?",bx+7,by+7,4,{0.05,0.05,0.05,1})

  g.pop()
end

local function drawPCMainFinal(game,state)
  local ox,oy,sc=partyLogicalCanvas()
  local g=love.graphics
  partyRenderOX,partyRenderOY,partyRenderScale=ox,oy,sc

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  local box=Boxes.active(game.save)
  drawPCBackground(game,"POKéMON PC",
    ("BOX %d   %d/%d"):format(game.save.currentBox or 1,#box,Boxes.CAPACITY))

  -- Left information panel mirrors the selected-Pokémon menu's visual frame.
  local lx,ly,lw,lh=4,23,72,96
  partySlotPanel(lx,ly,lw,lh,true)
  partyText("STORAGE",lx+7,ly+6,5,{0.06,0.06,0.06,1})
  partyText(("BOX %d"):format(game.save.currentBox or 1),lx+7,ly+18,6,
    {0.06,0.06,0.06,1})
  partyText(("%d / %d POKéMON"):format(#box,Boxes.CAPACITY),
    lx+7,ly+29,4,{0.18,0.18,0.16,1})
  partyText(("PARTY  %d / 6"):format(#(game.save.party or {})),
    lx+7,ly+37,4,{0.18,0.18,0.16,1})

  -- At-a-glance storage summary. The action list already exists on the right,
  -- so this space is more useful for persistent player/storage information.
  local seenCount=pokedexSeenCount(game.save)
  local ownedCount=pokedexOwnedCount(game.save)
  local pcTotal=totalStoredPokemon(game.save)

  partyText("POKéDEX",lx+7,ly+52,3,{0.30,0.28,0.22,1})
  partyText(tostring(seenCount).." SEEN",lx+9,ly+59,4.4,{0.08,0.08,0.08,1})
  partyText(tostring(ownedCount).." OWNED",lx+36,ly+59,4.4,{0.08,0.08,0.08,1})

  partyText("TOTAL IN PC",lx+7,ly+72,3,{0.30,0.28,0.22,1})
  partyText(tostring(pcTotal).." POKéMON",lx+9,ly+79,5,{0.08,0.08,0.08,1})

  -- Right action list.
  local rx,ry,rw,rh=80,23,76,96
  partySlotPanel(rx,ry,rw,rh,false)
  local items=state.items or {}
  local rowH=13
  for i,item in ipairs(items) do
    local y=ry+5+(i-1)*rowH
    local selected=i==(state.index or 1)
    if selected then
      g.setColor(0.10,0.10,0.10,1)
      roundedRect("fill",rx+4,y-1,rw-8,10,2)
      g.setColor(0.62,0.48,0.20,1)
      roundedRect("line",rx+5,y,rw-10,8,2)
    end
    local label=tostring(item.label or "")
      :gsub("<PK><MN>","POKéMON")
    partyText(label,rx+8,y,3,
      selected and {0.98,0.97,0.92,1} or {0.06,0.06,0.06,1})
  end

  -- Footer follows the same dark instruction strip as Party.
  g.setColor(0.08,0.08,0.08,1)
  g.rectangle("fill",4,127,152,13)
  partyText("Choose a PC action.",9,129,4,{0.98,0.98,0.96,1})

  g.pop()
end

local function drawPCListFinal(game,state)
  local ox,oy,sc=partyLogicalCanvas()
  local g=love.graphics
  partyRenderOX,partyRenderOY,partyRenderScale=ox,oy,sc

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  local title=tostring(state.title or "POKéMON PC")
  drawPCBackground(game,title,
    ("BOX %d"):format(game.save.currentBox or 1))

  local mon=pcSelectedMon(game,state)
  local lx,ly,lw,lh=4,23,69,101
  partySlotPanel(lx,ly,lw,lh,true)

  if mon then
    local def=game.data.pokemon[mon.species]
    local name=mon.nickname or (def and def.name) or "POKéMON"
    partyText(name,lx+7,ly+5,6,{0.06,0.06,0.06,1})

    local lv="Lv."..tostring(mon.level or "?")
    local lvw=partyTextWidth(lv,5)
    partyText(lv,lx+lw-7-lvw,ly+6,5,{0.06,0.06,0.06,1})

    local drew=drawSelectedBattleSprite(game,mon,lx+8,ly+16,30,27)
    if not drew then
      PartyMenu.drawIcon(game,mon,lx+7,ly+19,true,state.blink or 0)
    end

    -- Box Pokémon can have incomplete stats; keep details defensive.
    local maxhp=mon.stats and mon.stats.hp
    if maxhp then
      local hp=("%d/%d"):format(mon.hp or 0,math.max(1,maxhp))
      local hpw=partyTextWidth(hp,4)
      local hpX=lx+lw-7-hpw
      partyText("HP",lx+9,ly+44,4,{0.08,0.08,0.08,1})
      partyHPBarFinal(lx+21,ly+45,math.max(18,hpX-(lx+21)-3),mon)
      partyText(hp,hpX,ly+44,4,{0.08,0.08,0.08,1})
    else
      partyText("STORED POKéMON",lx+9,ly+45,3,{0.28,0.28,0.24,1})
    end

    drawPartyDetails(game,mon,lx,ly,lw,lh)
  else
    partyText("NO POKéMON",lx+16,ly+46,5,{0.25,0.25,0.22,1})
  end

  -- Right storage/party list uses the Party slot language.
  local items=state.items or {}
  local rx,rw=77,79
  local visible=math.min(6,#items)
  local scroll=state.scroll or 0
  for row=1,6 do
    local itemIndex=scroll+row
    local item=items[itemIndex]
    local y=23+(row-1)*17
    if item then
      local selected=itemIndex==(state.index or 1)
      partySlotPanel(rx,y,rw,16,selected)
      local label=tostring(item.label or "")
      partyText(label,rx+7,y+3,3,
        {0.06,0.06,0.06,1},"left",rw-14)
    else
      partySlotPanel(rx,y,rw,16,false)
    end
  end

  g.setColor(0.08,0.08,0.08,1)
  g.rectangle("fill",4,127,152,13)
  local up=tostring(state.title or ""):upper()
  local footer="Choose a POKéMON."
  if up:find("WITHDRAW",1,true) then
    footer="Withdraw which POKéMON?"
  elseif up:find("DEPOSIT",1,true) then
    footer="Deposit which POKéMON?"
  elseif up:find("RELEASE",1,true) then
    footer="Release which POKéMON?"
  elseif up=="CHANGE BOX" then
    footer="Choose a BOX."
  end
  partyText(footer,9,129,4,{0.98,0.98,0.96,1},"left",142)

  g.pop()
end

local function drawPCActionFinal(game,state)
  -- Preserve the PC list underneath, then draw a compact themed action card.
  local under=nil
  if game and game.stack and game.stack.states then
    for i=#game.stack.states-1,1,-1 do
      local s=game.stack.states[i]
      if s and s.__gen3uiPCList then under=s break end
    end
  end
  if under then drawPCListFinal(game,under) end

  local ox,oy,sc=partyLogicalCanvas()
  local g=love.graphics
  partyRenderOX,partyRenderOY,partyRenderScale=ox,oy,sc
  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  local x,y,w=105,74,48
  local items=state.items or {}
  local h=8+#items*12
  partySlotPanel(x,y,w,h,true)
  for i,item in ipairs(items) do
    local yy=y+5+(i-1)*12
    local selected=i==(state.index or 1)
    if selected then
      g.setColor(0.10,0.10,0.10,1)
      roundedRect("fill",x+4,yy-1,w-8,9,2)
    end
    partyText(tostring(item.label or ""),x+8,yy,3,
      selected and {0.98,0.97,0.92,1} or {0.06,0.06,0.06,1})
  end
  g.pop()
end

local function drawPartyFinal(game, state)
  local party = state.party or (game.save and game.save.party) or {}
  local ox,oy,sc = partyLogicalCanvas()
  local g = love.graphics

  -- Text helpers use these to escape the logical transform and render with
  -- battle-quality typography directly in final screen pixels.
  partyRenderOX, partyRenderOY, partyRenderScale = ox, oy, sc

  g.push("all")
  g.translate(ox,oy)
  g.scale(sc,sc)

  g.setColor(0.94,0.93,0.87,1)
  g.rectangle("fill",0,0,160,144)

  -- Header
  g.setColor(0.08,0.08,0.08,1)
  g.rectangle("fill",4,4,152,16)
  g.setColor(0.99,0.985,0.955,1)
  g.rectangle("fill",5,5,150,14)
  partyText(Strings("POKéMON"),10,6,6,{0.06,0.06,0.06,1})

  if #party == 0 then
    owText(Strings("No POKéMON!"),12,62,10,{0.06,0.06,0.06,1})
    g.pop()
    return
  end

  local selected = clamp(state.index or 1,1,#party)
  local mon = party[selected]
  local def = mon and game.data.pokemon[mon.species]

  -- Large selected detail panel on left.
  local lx,ly,lw,lh = 4,23,74,101
  partySlotPanel(lx,ly,lw,lh,true)

  if mon then
    -- Large selected portrait uses the active FRONT battle sprite. The six
    -- party entries on the right intentionally remain standard menu icons.
    local drewBattlePortrait = drawSelectedBattleSprite(
      game, mon,
      lx+7, ly+15,
      31, 27
    )
    if not drewBattlePortrait then
      -- Defensive fallback for a missing/invalid battle asset.
      PartyMenu.drawIcon(game,mon,lx+6,ly+18,true,state.blink or 0)
    end

    local name = mon.nickname or (def and def.name) or "POKéMON"
    partyText(name,lx+7,ly+5,6,{0.06,0.06,0.06,1})

    local lv = "Lv."..tostring(mon.level or "?")
    local lvw = partyTextWidth(lv,5)
    partyText(lv,lx+lw-7-lvw,ly+6,5,{0.06,0.06,0.06,1})

    -- HP mirrors the EXP row's visual rhythm, but reserves a right-side
    -- value slot so current/max HP stays on the same line as the bar.
    local hpY = ly + 43
    local hpLabelX = lx + 9
    local hpBarX = lx + 21

    local hp = ("%d/%d"):format(mon.hp or 0,
      math.max(1,mon.stats and mon.stats.hp or 1))
    local hpw = partyTextWidth(hp,4)
    local hpValueX = lx + lw - 7 - hpw
    local hpBarW = math.max(18, hpValueX - hpBarX - 3)

    partyText("HP",hpLabelX,hpY,4,{0.08,0.08,0.08,1})
    partyHPBarFinal(hpBarX,hpY+1,hpBarW,mon)
    partyText(hp,hpValueX,hpY,4,{0.08,0.08,0.08,1})

    local st = owStatus(mon)
    if st then
      partyText(st,lx+9,ly+51,4,
        st=="FNT" and {0.52,0.10,0.08,1} or {0.40,0.15,0.44,1})
    end

    -- Live Party EXP, matching the battle HUD's blue language.
    partyText("EXP",lx+9,ly+58,3,{0.34,0.45,0.50,1})
    drawPartyExpBar(game,mon,lx+21,ly+59,lw-29)

    local integratedLearn = activeMoveLearn
    if integratedLearn and integratedLearn.selecting
        and integratedLearn.mon == mon
        and canIntegrateMoveLearn(game, integratedLearn) then
      drawPartyMoveReplace(game,mon,lx,ly,lw,lh,integratedLearn)
    else
      drawPartyDetails(game,mon,lx,ly,lw,lh)
    end
  end

  -- All six Pokémon are always listed on the right, including the selected one.
  local rx,rw = 80,76
  local slotH,gap = 16,1
  for i,m in ipairs(party) do
    if i > 6 then break end
    local y = 23 + (i-1)*(slotH+gap)
    local isSelected = i == selected
    local d = game.data.pokemon[m.species]

    -- Selected row gets dark highlight, others stay light.
    if isSelected then
      g.setColor(0.10,0.10,0.10,1)
      roundedRect("fill",rx,y,rw,slotH,3)
      g.setColor(0.985,0.975,0.92,1)
      roundedRect("fill",rx+2,y+2,rw-4,slotH-4,2)
      -- Party screen is intentionally theme-locked.
      g.setColor(0.62,0.48,0.20,1)
      roundedRect("line",rx+3,y+3,rw-6,slotH-6,2)
      g.setColor(1,1,1,1)
    else
      partySlotPanel(rx,y,rw,slotH,false)
    end

    PartyMenu.drawIcon(game,m,rx+2,y,false,state.blink or 0)

    local name = m.nickname or (d and d.name) or "POKéMON"
    partyText(name,rx+19,y+1,4,{0.06,0.06,0.06,1})

    local lv = "Lv."..tostring(m.level or "?")
    local lvw = partyTextWidth(lv,5)
    partyText(lv,rx+rw-4-lvw,y+1,4,{0.06,0.06,0.06,1})

    if state.tmhm then
      local canLearn = false
      local monDef = game.data.pokemon[m.species]
      for _,moveId in ipairs((monDef and monDef.tmhm) or {}) do
        if moveId == state.tmhm.move then
          canLearn = true
          break
        end
      end

      local ableText = canLearn and "ABLE" or "NOT ABLE"
      local ableW = partyTextWidth(ableText,3)
      partyText(ableText,rx+rw-5-ableW,y+8,3,
        canLearn and {0.16,0.42,0.20,1} or {0.46,0.14,0.12,1})
    else
      partyText("HP",rx+19,y+8,3,{0.10,0.10,0.09,1})
      partyHPBarFinal(rx+31,y+10,rw-35,m)
    end
  end

  -- Bottom prompt.
  g.setColor(0.10,0.10,0.10,1)
  g.rectangle("fill",4,127,152,13)
  local prompt
  if activeMoveLearn and activeMoveLearn.selecting
      and canIntegrateMoveLearn(game, activeMoveLearn) then
    local moveId = activeMoveLearn.newMoveId
    local nd = moveId and game.data.moves[moveId] or nil
    local nn = (nd and nd.name) or tostring(moveId or "MOVE")
    local moveCount = #(activeMoveLearn.mon and activeMoveLearn.mon.moves or {})
    if (activeMoveLearn.index or 1) > moveCount then
      prompt = "CANCEL"
    else
      prompt = "Choose move to replace with "..nn.."."
    end
  else
    prompt = tostring(state:bottomMessage() or ""):gsub("\n"," ")
  end
  partyText(prompt,9,129,6,{1,1,1,1})

  -- Existing submenu.
  if state.submenu and state.subItems then
    local count=#state.subItems
    local sw=62
    local sh=math.min(66,6+count*12)
    local sx=160-sw-5
    local sy=math.max(5,124-sh)
    frlgMenuPanel(sx,sy,sw,sh)

    for si,entry in ipairs(state.subItems) do
      local yy=sy+4+(si-1)*12
      if si==state.subIndex then
        frlgSelection(sx+3,yy,sw-6,11)
        partyText(entry.label,sx+8,yy+1,6,{1,1,1,1})
      else
        partyText(entry.label,sx+8,yy+1,6,{0.06,0.06,0.06,1})
      end
    end
  end

  g.setColor(1,1,1,1)
  g.pop()
end

-- -------------------------------------------------------------------------

-- -------------------------------------------------------------------------
-- Final-HUD themed dialogue / choice overlay
-- -------------------------------------------------------------------------

local function dialogueVisibleText(box, shownIndex)
  local shown = box.shown and box.shown[shownIndex]
  if not shown then return "" end

  local page = box.pages and box.pages[box.pageIndex]
  if not page then return "" end

  local sourceIndex = box.lineIndex - (#box.shown - shownIndex)
  local source = page[sourceIndex] or ""
  local spans = EngineFont.split(source)

  local count = math.min(#shown, #spans)
  if count <= 0 then return "" end
  return source:sub(1, spans[count].to)
end

local function drawDialogueThemeFinal(box)
  local g = love.graphics
  local sw,sh = g.getDimensions()
  local sc = math.max(1,sh/144)
  local margin = math.floor(4*sc+0.5)
  -- v0.1's 32 logical pixels left a large empty lower half on modern
  -- displays. Keep the same full-width style but use a tighter 24px body.
  local h = math.floor(24*sc+0.5)
  local x = margin
  local y = sh-h-margin
  local w = sw-margin*2

  g.push("all")
  g.origin()

  g.setColor(0.04,0.04,0.04,0.30)
  g.rectangle("fill",x+2*sc,y+2*sc,w,h)
  g.setColor(0.08,0.08,0.07,1)
  g.rectangle("fill",x,y,w,h)
  g.setColor(0.99,0.985,0.95,1)
  g.rectangle("fill",x+2*sc,y+2*sc,w-4*sc,h-4*sc)
  drawUnifiedBorder(x,y,w,h,0)

  local off = box.scrollPx or 0
  local preferred = math.max(14,math.floor(6.2*sc+0.5))
  local minimum = math.max(10,math.floor(preferred*0.64+0.5))
  local textX = math.floor(x+7*sc+0.5)
  local contentW = math.max(1,math.floor(w-14*sc+0.5))
  local shown = box.shown or {}
  local visible = math.min(2,#shown)
  local texts = {}

  for i=1,visible do
    texts[i] = dialogueVisibleText(box,i)
  end

  local innerTop=math.max(3,math.floor(3*sc+0.5))
  local innerBottom=math.max(4,math.floor(4*sc+0.5))
  local innerH=math.max(1,h-innerTop-innerBottom)

  local pxSize,glyphH,lineH,blockH=fittedDialogueMetrics(
    texts,preferred,minimum,contentW,innerH)

  local firstY=y+innerTop+math.max(0,(innerH-blockH)*0.5)+off

  -- Same metric-driven layout as battle dialogue.
  g.setScissor(
    math.floor(x+5*sc),
    math.floor(y+innerTop-1),
    math.floor(w-10*sc),
    math.floor(innerH+2)
  )
  for i=1,visible do
    local ty=math.floor(firstY+(i-1)*lineH+0.5)
    printText(texts[i],textX,ty,pxSize,{0.04,0.04,0.04,1},
      "left",contentW)
  end
  g.setScissor()

  if (box.waiting or (box.done and not box.choice and not box.auto and not box.stay))
      and (box.blink or 0) < 30 then
    printText("▼",math.floor(x+w-12*sc),math.floor(y+h-10*sc),
      math.max(10,math.floor(4*sc+0.5)),{0.10,0.10,0.09,1})
  end

  g.pop()
end
local function drawChoiceThemeFinal(box)
  local g = love.graphics
  local sw,sh = g.getDimensions()
  local sc = math.max(1,sh/144)

  local margin = math.floor(4*sc+0.5)
  local dialogueH = math.floor(24*sc+0.5)
  local w = math.floor(48*sc+0.5)
  local h = math.floor(34*sc+0.5)
  local x = sw-w-margin
  local y = sh-dialogueH-margin-h-math.floor(3*sc+0.5)

  g.push("all")
  g.origin()
  g.setColor(0.08,0.08,0.07,1)
  g.rectangle("fill",x,y,w,h)
  g.setColor(0.99,0.985,0.95,1)
  g.rectangle("fill",x+2*sc,y+2*sc,w-4*sc,h-4*sc)
  drawUnifiedBorder(x,y,w,h,0)

  local row1 = math.floor(y+5*sc+0.5)
  local row2 = math.floor(y+18*sc+0.5)
  local selected = box.index or 1
  g.setColor(0.10,0.10,0.09,1)
  g.rectangle("fill",x+5*sc,(selected==1 and row1 or row2)-sc,w-10*sc,11*sc)

  local pxSize = math.max(12,math.floor(5*sc+0.5))
  printText(Strings("YES"),math.floor(x+10*sc),row1,pxSize,
    selected==1 and {1,1,1,1} or {0.04,0.04,0.04,1})
  printText(Strings("NO"),math.floor(x+10*sc),row2,pxSize,
    selected==2 and {1,1,1,1} or {0.04,0.04,0.04,1})
  g.pop()
end
local function installDialogueThemeDirect(mod)
  local originalTextBoxDraw = TextBox.draw
  TextBox.draw = function(self)
    if not featureEnabled("revampedDialogueBoxes") then
      activeDialogueBox = nil
      return originalTextBoxDraw(self)
    end

    -- Revamped mode is exclusive: suppress the vanilla box completely.
    -- Mark this TextBox for final-HUD rendering in the current frame.
    activeDialogueBox = self

    -- Preserve the only draw-time state mutation from vanilla TextBox.draw:
    -- the 8px scroll animation decays by 2px per rendered frame.
    if self.scrollPx and self.scrollPx > 0 then
      self.scrollPx = self.scrollPx - 2
      if self.scrollPx <= 0 then self.scrollPx = nil end
    end

    local r = self.game and self.game.renderer
    if r and r.setUIAnchor then
      r:setUIAnchor(self.boxTx * 8, self.boxTy * 8,
                    self.boxTw * 8, self.boxTh * 8, "bottom")
    end
  end

  local originalChoiceDraw = ChoiceBox.draw
  ChoiceBox.draw = function(self)
    if not featureEnabled("revampedDialogueBoxes") then
      activeChoiceBox = nil
      return originalChoiceDraw(self)
    end

    -- Same exclusive behavior for YES / NO and other ChoiceBox prompts.
    activeChoiceBox = self
  end

  if mod.log then
    mod.log:info("Gen 3 Inspired UI Overhaul: final-HUD dialogue overlay installed")
  end
end


-- Entry
-- -------------------------------------------------------------------------


local function installPCIntegration()
  -- Bill's PC uses generic Menu/ListMenu classes internally. Mark only the
  -- exact PC-owned instances so our renderer stays compatible with unrelated
  -- menus and other mods.
  local originalBoxMenuNew=BoxMenu.new
  BoxMenu.new=function(game,...)
    local menu=originalBoxMenuNew(game,...)
    if menu then
      menu.__gen3uiPCMain=true

      -- BoxMenu installs a per-instance draw() that appends the native
      -- "What?" / "BOX No." chrome after Menu.draw. Replace only THIS
      -- BoxMenu instance's presentation hook; update/input remain native.
      local nativeBoxDraw=menu.draw
      menu.__gen3uiNativeBoxDraw=nativeBoxDraw
      menu.draw=function(self)
        if not featureEnabled("revampedPokemonPC") then
          return nativeBoxDraw(self)
        end
        activePCMenu=self
      end
    end
    return menu
  end

  local originalMenuNew=Menu.new
  Menu.new=function(game,items,opts,...)
    local menu=originalMenuNew(game,items,opts,...)
    if menu then
      if pcAccessItems(items) then
        menu.__gen3uiPCAccess=true
      elseif pcMainItems(items) then
        menu.__gen3uiPCMain=true
      elseif pcActionItems(items) then
        menu.__gen3uiPCAction=true
      end
    end
    return menu
  end

  local originalListMenuNew=ListMenu.new
  ListMenu.new=function(game,title,items,opts,...)
    local list=originalListMenuNew(game,title,items,opts,...)
    if list and pcListTitle(title) then
      list.__gen3uiPCList=true
      list.__gen3uiPCTitle=title
    end
    return list
  end
end


local function handleModOptionChanged(mod,payload)
  if not payload or payload.mod ~= mod.id then return end

  if payload.key == "revampedBattleUI" and payload.value == false then
    activeBattle = nil
  elseif payload.key == "revampedPokemonMenu" and payload.value == false then
    activeParty = nil
    activeTMParty = nil
    activeMoveLearn = nil
    activeTMPromptFlow = nil
  elseif payload.key == "revampedOverworldMenus" and payload.value == false then
    activeStartMenu = nil
    activeBagMenu = nil
    activeBagActionMenu = nil
  elseif payload.key == "revampedPokemonPC" and payload.value == false then
    activePCAccessMenu = nil
    activePCMenu = nil
    activePCList = nil
    activePCActionMenu = nil
  elseif payload.key == "revampedDialogueBoxes" and payload.value == false then
    activeDialogueBox=nil
    activeChoiceBox=nil
  end
end


local function battleOverlayHook(next,battle)
  next(battle)
  activeBattle=battle
end

local function renderHudHook(mod,next,game,viewport)
  patchDramaticShape(game, mod)
  next(game, viewport)

  if not (love and love.graphics) then return end

  local topNow=topState(game)
  if topNow and not supportedOverworldMenuState(topNow)
      and not topNow.__gen3uiStart
      and getmetatable(topNow)~=TextBox
      and getmetatable(topNow)~=ChoiceBox
      and getmetatable(topNow)~=NamingScreen
      and topNow~=activeBattle then
    -- Unknown/unsupported foreground menus (PC/storage/etc.) are fully
    -- native. Drop stale replacement ownership instead of drawing over them.
    activeStartMenu=nil
    activeBagMenu=nil
    activeBagActionMenu=nil
  end

  -- NamingScreen is a complete opaque native UI with its own letter grid.
  -- Never composite our menus/dialogue/battle HUD over it. This also makes
  -- mod-provided naming screens using the standard screenId contract fail-soft.
  if namingScreenOwnsForeground(game) then
    activeDialogueBox=nil
    activeChoiceBox=nil
    activeStartMenu=nil
    activeBagMenu=nil
    activeBagActionMenu=nil
    activeParty=nil
    activeTMParty=nil
    activeMoveLearn=nil
    activeTMPromptFlow=nil
    activePCAccessMenu=nil
    activePCMenu=nil
    activePCList=nil
    activePCActionMenu=nil
    return
  end

  -- Bill's PC / storage screens use the same full-resolution visual
  -- language as Party. Only explicitly marked PC states are intercepted.
  local pcTop=topState(game)
  if pcTop and isPCOwnedState(pcTop) and featureEnabled("revampedPokemonPC") then
    if pcTop.__gen3uiPCAccess then
      activePCAccessMenu=pcTop
      activePCMenu=nil
      activePCList=nil
      activePCActionMenu=nil
      local ok,err=pcall(drawPCAccessFinal,game,pcTop)
      if (not ok) and mod.log then
        mod.log("error","Gen 3 UI PC access renderer failed: "..tostring(err))
      end
      return
    elseif pcTop.__gen3uiPCMain then
      activePCMenu=pcTop
      activePCAccessMenu=nil
      activePCList=nil
      activePCActionMenu=nil
      local ok,err=pcall(drawPCMainFinal,game,pcTop)
      if (not ok) and mod.log then
        mod.log("error","Gen 3 UI PC main renderer failed: "..tostring(err))
      end
      return
    elseif pcTop.__gen3uiPCList then
      activePCList=pcTop
      activePCAccessMenu=nil
      activePCMenu=nil
      activePCActionMenu=nil
      local ok,err=pcall(drawPCListFinal,game,pcTop)
      if (not ok) and mod.log then
        mod.log("error","Gen 3 UI PC list renderer failed: "..tostring(err))
      end
      return
    elseif pcTop.__gen3uiPCAction then
      activePCActionMenu=pcTop
      local ok,err=pcall(drawPCActionFinal,game,pcTop)
      if (not ok) and mod.log then
        mod.log("error","Gen 3 UI PC action renderer failed: "..tostring(err))
      end
      return
    end
  end

  if activeMoveLearn and not stateExistsInStack(game, activeMoveLearn) then
    activeMoveLearn = nil
  end
  if activeTMPromptFlow and not stateExistsInStack(game, activeTMPromptFlow) then
    activeTMPromptFlow = nil
  end

  -- Bag-owned USE/TOSS/etc menu: the Bag remains the full background while
  -- the small action menu is drawn on top in the same final-resolution pass.
  if activeBagActionMenu then
    local bag = bagStateForMenu(game)
    if bag and uiTopState(game, activeBagActionMenu)
        and featureEnabled("revampedOverworldMenus") then
      local okBagBg, errBagBg = pcall(drawBagFinal, game, bag)
      if (not okBagBg) and mod.log then
        mod.log("error","Gen 3 UI Bag action background failed: "..tostring(errBagBg))
      end

      local okAction, errAction = pcall(drawBagActionFinal, game, activeBagActionMenu)
      if (not okAction) and mod.log then
        mod.log("error","Gen 3 UI Bag action overlay failed: "..tostring(errAction))
      end
      return
    else
      activeBagActionMenu = nil
    end
  end

  -- During TM/HM boot-up dialogue the actual Bag ListMenu is still in
  -- game.stack underneath the TextBox. Draw THAT live state directly.
  -- This is intentionally independent of whether ListMenu.draw ran this frame.
  if activeDialogueBox and not activeTMParty and not activeParty
      and featureEnabled("revampedOverworldMenus") then
    local bagUnderDialogue = findBagStateInStack(game)
    if bagUnderDialogue then
      local okBagBg, errBagBg = pcall(drawBagFinal, game, bagUnderDialogue)
      if (not okBagBg) and mod.log then
        mod.log("error","Gen 3 UI live Bag underlay failed: "..tostring(errBagBg))
      end
    end
  end

  -- TM/HM Party is a persistent BACKGROUND layer. It must render before
  -- dialogue/teach overlays, because those overlays may return from this HUD pass.
  if activeTMParty then
    local tmBackgroundWanted =
      partyShouldRenderBehindTM(game, activeTMParty)
      or (activeTMPromptFlow and stateExistsInStack(game, activeTMParty))

    if featureEnabled("revampedPokemonMenu") and tmBackgroundWanted then
      local okTMParty, errTMParty = pcall(drawPartyFinal, game, activeTMParty)
      if (not okTMParty) and mod.log then
        mod.log("error", "Gen 3 Inspired UI Overhaul TM Party background failed: "..tostring(errTMParty))
      end
    elseif not partyInStack(game, activeTMParty) then
      activeTMParty = nil
    end
  end

  -- PC-owned TextBox/ChoiceBox prompts sit above BoxMenu/ListMenu on the
  -- native stack. Re-render the nearest marked PC state here so confirmation
  -- and transfer messages retain our custom PC background, never native chrome.
  if (activeDialogueBox or activeChoiceBox)
      and featureEnabled("revampedPokemonPC") then
    local pcUnder=pcStateInStack(game)
    if pcUnder then
      if pcUnder.__gen3uiPCAccess then
        pcall(drawPCAccessFinal,game,pcUnder)
      elseif pcUnder.__gen3uiPCMain then
        pcall(drawPCMainFinal,game,pcUnder)
      elseif pcUnder.__gen3uiPCList then
        pcall(drawPCListFinal,game,pcUnder)
      elseif pcUnder.__gen3uiPCAction then
        pcall(drawPCActionFinal,game,pcUnder)
      end
    end
  end

  -- Dialogue/choices were marked by their native draw calls earlier this frame.
  -- Render ONLY the themed version now, outside the palette compositor.
  local drewDialogue = false

  if activeDialogueBox and featureEnabled("revampedDialogueBoxes") then
    local box = activeDialogueBox
    activeDialogueBox = nil

    local okDialogue, errDialogue = pcall(drawDialogueThemeFinal, box)
    if not okDialogue then
      box.__gen3uiNativeFallback=true
      if mod.log then
        mod.log("error","Gen 3 UI final dialogue overlay failed: "..tostring(errDialogue))
      end
    end
    drewDialogue=okDialogue
  else
    activeDialogueBox = nil
  end

  if activeChoiceBox and featureEnabled("revampedDialogueBoxes") then
    local choice = activeChoiceBox
    activeChoiceBox = nil

    -- Battle sayChoice pushes ChoiceBox ABOVE BattleState while keeping the
    -- completed prompt in battle.current. Draw that prompt explicitly before
    -- the choice; otherwise our normal battle renderer yields to the pushed
    -- state and the user sees the previous "about to use" page freeze.
    local battleUnderChoice=activeBattle
    if battleInStack(game,battleUnderChoice)
        and battleUnderChoice.phase=="messages"
        and battleUnderChoice.current then
      local okPrompt,errPrompt=pcall(drawDialogue,battleUnderChoice)
      if (not okPrompt) and mod.log then
        mod.log("error","Gen 3 UI battle choice prompt failed: "..tostring(errPrompt))
      end
    end

    local okChoice, errChoice = pcall(drawChoiceThemeFinal, choice)
    if (not okChoice) and mod.log then
      mod.log("error","Gen 3 UI final choice overlay failed: "..tostring(errChoice))
    end
    return
  else
    activeChoiceBox = nil
  end

  if drewDialogue then
    return
  end

  -- START / Bag draw after the palettized screen pass, like Party.
  if activeStartMenu and uiTopState(game, activeStartMenu) then
    local okStart, errStart = pcall(drawStartFinal, game, activeStartMenu)
    if (not okStart) and mod.log then
      mod.log("error","Gen 3 Inspired UI Overhaul START renderer failed: "..tostring(errStart))
    end
    return
  elseif activeStartMenu then
    activeStartMenu = nil
  end

  if activeBagMenu and uiTopState(game, activeBagMenu) then
    local okBag, errBag = pcall(drawBagFinal, game, activeBagMenu)
    if (not okBag) and mod.log then
      mod.log("error","Gen 3 Inspired UI Overhaul Bag renderer failed: "..tostring(errBag))
    end
    return
  elseif activeBagMenu then
    activeBagMenu = nil
  end

  -- Draw Party after the palettized screen pass, preserving true neutral colors.
  if activeParty and partyTopState(game, activeParty) then
    local okParty, errParty = pcall(drawPartyFinal, game, activeParty)
    if (not okParty) and mod.log then
      mod.log("error", "Gen 3 Inspired UI Overhaul party renderer failed: "..tostring(errParty))
    end
    return
  elseif activeParty and partyShouldRenderBehindTM(game, activeParty) then
    -- Kept-open TM/HM Party backgrounds are already drawn at the beginning
    -- of render.hud so dialogue/teach overlays can safely render on top.
    activeTMParty = activeParty
  elseif activeParty then
    activeParty = nil
  end

  local battle = activeBattle
  if not featureEnabled("revampedBattleUI") then
    activeBattle = nil
    return
  end
  if not battleInStack(game, battle) then
    activeBattle = nil
    return
  end

  -- If Bag / Party / Summary / another pushed state owns the foreground,
  -- preserve activeBattle but draw none of our battle UI over that screen.
  if not battleOwnsForeground(game, battle) then
    return
  end

  local cmd = commandGeometry()
  local s = hudScale()

  -- Preserve intro / replacement party-count information hidden with the
  -- native HUD. This is presentation only; battle party data stays native.
  -- Status HUD remains visible for normal battle messages and the main
  -- FIGHT/POKEMON/BAG/RUN prompt, but yields the screen to full move select.
  love.graphics.push("all")
  local okStatus, errStatus = pcall(function()
    if shouldDrawStatusHUD(game, battle) then
      drawEnemyHUD(battle, s)
      drawPlayerHUD(battle, s, cmd)
    end
  end)
  love.graphics.pop()

  love.graphics.push("all")
  local okUI, errUI = pcall(function()
    drawDialogue(battle)
    drawCommandMenu(battle)
    drawMoveSelect(battle)
  end)
  love.graphics.pop()

  if mod.log then
    if not okStatus then
      mod.log("error", "Gen 3 Inspired UI Overhaul status HUD failed: "..tostring(errStatus))
    end
    if not okUI then
      mod.log("error", "Gen 3 Inspired UI Overhaul battle UI failed: "..tostring(errUI))
    end
  end
end

return function(mod)
  installVerifiedOptions(mod)

  installPCIntegration()
  installDialogueThemeDirect(mod)
  if mod.events and mod.events.on then
    mod.events:on("mod.options_changed", function(payload)
      handleModOptionChanged(mod,payload)
    end)
  end
  patchVanillaTextDrawing()
  installOverworldUI(mod)

  mod.hooks:wrap("battle.overlay", battleOverlayHook, 9000)
  mod.hooks:wrap("render.hud", function(next,game,viewport)
    return renderHudHook(mod,next,game,viewport)
  end, 10000)

end
