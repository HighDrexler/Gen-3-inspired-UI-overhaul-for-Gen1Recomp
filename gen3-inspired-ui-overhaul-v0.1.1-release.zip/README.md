# Gen 3 Inspired UI Overhaul — v0.1.1

A Gen 3-inspired presentation overhaul for Pokemon Red: Gen 1 Recompilation.

The mod modernizes presentation while preserving native gameplay, battle logic,
menu input, PC/storage behavior, and TM move-learning rules.

## Features

- Revamped battle HUD and command menu
- Responsive move-selection interface
- Redesigned Pokemon party menu
- Selected-Pokemon HP, EXP, moves, PP, and stats
- Integrated TM move-replacement presentation
- Native TM prompts and move-learning logic preserved
- Redesigned dialogue and choice boxes
- Revamped Start/Bag/overworld menus
- Dedicated Pokemon PC/storage interface
- PC summary with Pokedex Seen, Owned, and total Pokemon stored across all boxes
- Trainer-battle intro party-count indicator
- Responsive windowed/fullscreen/1440p/4K scaling
- Slightly enlarged/heavier menu typography for readability
- Border color and border style customization
- Independent feature toggles in the Mod Manager

## Mod options

- BATTLE UI
- POKEMON MENU
- OVERWORLD MENUS
- POKEMON PC UI
- DIALOGUE / TEXT BOXES
- BORDER COLOR
- BORDER STYLE

Each major presentation subsystem can be disabled independently. When disabled,
the mod delegates that subsystem back to the existing/native renderer.

## Compatibility approach

The mod tries to be friendly to large mod stacks:

- shared engine draw methods are chained instead of assumed to be vanilla
- native draw lifecycles are preserved where practical
- unsupported/unknown menu states fall back to native presentation
- naming screens remain native
- PC/storage input and storage logic remain native
- TM input/state progression remains native
- invasive renderer mods may still require dedicated compatibility work

## Source layout

- `main.lua` — runtime hooks and rendering
- `manifest.json` — mod metadata
- `README.md` — project overview
- `CHANGELOG.md` — release history

No custom font files or bitmap UI assets are bundled.

## Versioning

`0.1.1` is the first stability/compatibility maintenance release after the
initial `0.1` baseline.
