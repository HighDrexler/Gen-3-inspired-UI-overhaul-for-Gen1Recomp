# Gen 3 Inspired UI Overhaul — v0.1

A Gen 3-inspired presentation overhaul for Pokemon Red: Gen 1 Recompilation.

The mod changes presentation only. Gameplay, battle logic, progression, menu
flow, TM behavior, and move-learning rules remain native.

## Features

- Revamped battle HUD and command menu
- Responsive move-selection panel
- Redesigned Pokemon party menu
- Selected-Pokemon HP, EXP, moves, PP and stats
- Integrated TM move-replacement presentation
- Native TM prompts and move-learning logic preserved
- Redesigned dialogue boxes
- Revamped overworld/start menus
- Gen 3-inspired typography and borders
- Responsive fullscreen/windowed scaling
- Independent feature toggles
- Border color and border style customization

## Source layout

The v0.1 source is intentionally small and readable:

- `main.lua` — mod behavior and rendering
- `manifest.json` — mod metadata
- `README.md` — project overview
- `CHANGELOG.md` — release history

No custom image or font assets are bundled. The interface is drawn
procedurally and uses Gen1Recomp's existing fonts and Pokemon sprite systems.

## Compatibility

Normal sprite replacements using Gen1Recomp's standard battle-sprite pipeline
may appear in the selected-Pokemon portrait. More invasive battle renderers may
require dedicated compatibility work.

## Development baseline

v0.1 is the starting public baseline. Future 0.x releases can focus on polish,
bug fixes, compatibility, and accessibility before a future 1.0.
