# Changelog

## 0.1

Initial public baseline for Gen 3 Inspired UI Overhaul.

This is the starting point for continued polish, compatibility work, bug fixes,
and refinement.

Included in this baseline:
- Gen 3-inspired battle HUD and command presentation
- Responsive move-selection interface
- Redesigned Pokemon party screen
- Selected-Pokemon HP, EXP, moves, PP and stats
- Integrated TM move replacement in the Pokemon menu
- Native TM prompts and move-learning flow preserved
- Redesigned dialogue/menu boxes
- Independent mod-option toggles
- Border color and border style customization
- Responsive widescreen/windowed presentation
- Windowed battle typography/layout tightening

This version should not be treated as feature-final or compatibility-final.
