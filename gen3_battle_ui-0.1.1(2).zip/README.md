# Gen 3 Inspired UI Overhaul — v0.1.1

A Gen 3-inspired presentation overhaul for Pokémon Red: Gen1Recomp.

The mod modernizes presentation while preserving native gameplay, battle logic,
menu input, storage behavior, and TM move-learning rules.

## Highlights

- Revamped battle HUD, command menu, and move selection
- Redesigned Pokémon party menu with selected-Pokémon details
- Integrated TM move-replacement presentation with native logic preserved
- Redesigned dialogue and choice boxes
- Revamped Start Menu, Bag, and overworld menu presentation
- Dedicated Pokémon PC interface
- PC summary showing Pokédex Seen, Owned, and total Pokémon stored across all boxes
- Proper scrolling for PC storage lists beyond the first six entries
- Intro-only trainer party-count indicator
- Improved windowed/fullscreen/1440p/4K readability
- Slightly enlarged/heavier shared menu typography
- Border color and style customization
- Independent feature toggles, including a dedicated Pokémon PC UI toggle
- Native fallbacks for unsupported/unknown states

## Mod options

- BATTLE UI
- POKÉMON MENU
- OVERWORLD MENUS
- POKÉMON PC UI
- DIALOGUE / TEXT BOXES
- BORDER COLOR
- BORDER STYLE

## Updater support

This mod is linked to:

`HighDrexler/Gen-3-inspired-UI-overhaul-for-Gen1Recomp`

For Gen1Recomp's native updater, publish launcher-ready GitHub Release assets
using the naming convention:

`gen3_battle_ui-X.Y.Z.zip`

For this release:

`gen3_battle_ui-0.1.1.zip`

The archive must be attached under the GitHub Release's **Assets** section.

## Compatibility approach

- Shared engine draw methods are chained rather than assumed to be vanilla
- Native draw lifecycles are preserved where practical
- Unknown menu states fall back to native presentation
- Naming screens remain native
- PC/storage logic remains native
- TM input/state progression remains native
- Large mod stacks should degrade safely where possible
- Renderer-heavy mods may still need dedicated compatibility work

## Package contents

- `manifest.json`
- `main.lua`
- `README.md`
- `CHANGELOG.md`
