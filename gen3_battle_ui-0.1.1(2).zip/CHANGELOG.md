# Changelog

## 0.1.1

First major stability and compatibility update.

- Fixed duplicate native battle UI showing behind the custom battle UI
- Preserved native battle draw lifecycle while suppressing legacy HUD pixels
- Fixed trainer-switch dialogue progression and CONT-page rendering
- Stabilized battle-dialogue font size during typewriter reveal
- Improved dialogue sizing, clipping, spacing, and high-resolution scaling
- Preserved native nickname/NamingScreen presentation
- Improved 1440p/4K typography scaling
- Tightened selected-Pokémon HP bar/value alignment
- Added dedicated Pokémon PC interface and independent PC toggle
- Themed PC access, storage, withdraw, deposit, release, and action flows
- Suppressed native PC chrome behind the custom PC interface
- Added Pokédex Seen and Owned counts to the PC summary
- Added total Pokémon stored across all boxes
- Fixed PC storage list scrolling beyond the first six entries
- Added intro-only trainer party-count indicator
- Slightly enlarged and strengthened shared menu typography
- Preserved Start Menu, Bag, TM, storage, and battle logic
- Refactored initialization to avoid LuaJIT upvalue limits
- Added GitHub updater metadata for native Gen1Recomp update checks

## 0.1

Initial public baseline.
